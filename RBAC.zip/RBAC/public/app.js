document.addEventListener('DOMContentLoaded', () => {
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    if (emailInput && passwordInput) {
        const demoMap = {
            admin: ['admin@rbac.test', 'Admin@123'],
            manager: ['manager@rbac.test', 'Manager@123'],
            user: ['user@rbac.test', 'User@1234'],
        };

        document.querySelectorAll('[data-demo]').forEach((button) => {
            button.addEventListener('click', () => {
                const type = button.dataset.demo;
                if (demoMap[type]) {
                    emailInput.value = demoMap[type][0];
                    passwordInput.value = demoMap[type][1];
                }
            });
        });
    }
});
