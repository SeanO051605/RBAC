<?php

$projectRoot = dirname(__DIR__);
$envFile = $projectRoot . '/.env';

if (is_file($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES);
    if ($lines === false) {
        throw new RuntimeException('Unable to read the application environment file.');
    }

    foreach ($lines as $lineNumber => $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        if (!preg_match('/^([A-Z][A-Z0-9_]*)\s*=\s*(.*)$/', $line, $matches)) {
            throw new RuntimeException('Invalid environment entry on line ' . ($lineNumber + 1) . '.');
        }

        [, $key, $value] = $matches;
        if (getenv($key) !== false) {
            continue;
        }

        $value = trim($value);
        if (
            strlen($value) >= 2
            && (($value[0] === '"' && str_ends_with($value, '"'))
                || ($value[0] === "'" && str_ends_with($value, "'")))
        ) {
            $value = substr($value, 1, -1);
        } else {
            $value = preg_replace('/\s+#.*$/', '', $value);
        }

        putenv($key . '=' . $value);
        $_ENV[$key] = $value;
    }
}

$requiredVariables = ['DB_HOST', 'DB_PORT', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];
$environment = [];
foreach ($requiredVariables as $variable) {
    $value = getenv($variable);
    if ($value === false) {
        throw new RuntimeException(
            'Missing ' . $variable . '. Set it in the project .env file or the server environment.'
        );
    }
    $environment[$variable] = $value;
}

$port = filter_var($environment['DB_PORT'], FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1, 'max_range' => 65535],
]);
if ($port === false) {
    throw new RuntimeException('DB_PORT must be a valid TCP port.');
}

return [
    'host' => $environment['DB_HOST'],
    'port' => $port,
    'database' => $environment['DB_DATABASE'],
    'username' => $environment['DB_USERNAME'],
    'password' => $environment['DB_PASSWORD'],
];
