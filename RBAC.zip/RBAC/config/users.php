<?php

return [
    [
        'id' => 1,
        'name' => 'Ada Admin',
        'email' => 'admin@rbac.test',
        'password' => '$2y$12$O1uYAyWI8AoF/nWNMQKRUuVZ4Jf5I2f04f/CUX9UNmpuiLWKvDhA.',
        'role' => 'admin',
        'status' => 'active',
        'created_at' => '2024-01-15T09:30:00+00:00',
    ],
    [
        'id' => 2,
        'name' => 'Mia Manager',
        'email' => 'manager@rbac.test',
        'password' => '$2y$12$rXaYYo5VoNU19LYL4bzVT.tlzG3mXamd1aujP.eBfdwBf56R7MDCO',
        'role' => 'manager',
        'status' => 'active',
        'created_at' => '2024-02-01T10:15:00+00:00',
    ],
    [
        'id' => 3,
        'name' => 'Uli User',
        'email' => 'user@rbac.test',
        'password' => '$2y$12$R57O/rkwmWngxkpXVeyg4uyldD8oJhyH1uEkXtgXJkwA5RR1iTmjC',
        'role' => 'user',
        'status' => 'active',
        'created_at' => '2024-03-10T08:45:00+00:00',
    ],
];
