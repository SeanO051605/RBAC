<?php

namespace App\Models;

use PDO;

class InvitationModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function create(string $name, string $email, int $roleId, int $invitedBy): string
    {
        $token = bin2hex(random_bytes(32));
        $statement = $this->db->prepare(
            "INSERT INTO invitations (email, name, token_hash, role_id, invited_by, expires_at)
             VALUES (:email, :name, :token_hash, :role_id, :invited_by, DATE_ADD(NOW(), INTERVAL 7 DAY))"
        );
        $statement->execute([
            'email' => strtolower(trim($email)),
            'name' => trim($name),
            'token_hash' => hash('sha256', $token),
            'role_id' => $roleId,
            'invited_by' => $invitedBy,
        ]);

        return $token;
    }

    public function existsForEmail(string $email): bool
    {
        $statement = $this->db->prepare(
            "SELECT 1 FROM invitations
             WHERE email = :email AND status = 'pending' AND expires_at > NOW()
             LIMIT 1"
        );
        $statement->execute(['email' => strtolower(trim($email))]);

        return (bool) $statement->fetchColumn();
    }

    public function pending(): array
    {
        return $this->db->query(
            "SELECT i.id, i.email, i.name, i.role_id, i.expires_at, i.created_at, r.name AS role_name,
                    COALESCE(u.name, 'Former user') AS inviter_name
             FROM invitations i
             JOIN roles r ON r.id = i.role_id
             LEFT JOIN users u ON u.id = i.invited_by
             WHERE i.status = 'pending' AND i.expires_at > NOW()
             ORDER BY i.created_at DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function cancel(int $id): void
    {
        $statement = $this->db->prepare(
            "UPDATE invitations SET status = 'cancelled' WHERE id = :id AND status = 'pending'"
        );
        $statement->execute(['id' => $id]);
    }

    public function cancelByEmail(string $email): void
    {
        $statement = $this->db->prepare(
            "UPDATE invitations SET status = 'cancelled'
             WHERE email = :email AND status = 'pending'"
        );
        $statement->execute(['email' => strtolower(trim($email))]);
    }

    public function findValid(string $token): ?array
    {
        $statement = $this->db->prepare(
            "SELECT i.id, i.email, i.name, i.role_id, r.slug AS role_slug
             FROM invitations i
             JOIN roles r ON r.id = i.role_id AND r.status = 'active'
             WHERE i.token_hash = :token_hash AND i.status = 'pending' AND i.expires_at > NOW()
             LIMIT 1"
        );
        $statement->execute(['token_hash' => hash('sha256', $token)]);

        return $statement->fetch(PDO::FETCH_ASSOC) ?: null;
    }

}
