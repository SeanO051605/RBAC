<?php

namespace App\Models;

use PDO;

class AuditLogModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function record(
        ?int $actorId,
        string $action,
        string $targetType,
        ?string $targetId = null,
        ?array $before = null,
        ?array $after = null,
        string $result = 'success'
    ): void {
        $statement = $this->db->prepare(
            'INSERT INTO audit_logs
                (actor_id, action, target_type, target_id, before_data, after_data, ip_address, user_agent, result)
             VALUES
                (:actor_id, :action, :target_type, :target_id, :before_data, :after_data, :ip_address, :user_agent, :result)'
        );
        $statement->execute([
            'actor_id' => $actorId,
            'action' => $action,
            'target_type' => $targetType,
            'target_id' => $targetId,
            'before_data' => $before === null ? null : json_encode($before, JSON_THROW_ON_ERROR),
            'after_data' => $after === null ? null : json_encode($after, JSON_THROW_ON_ERROR),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 500) : null,
            'result' => $result,
        ]);
    }

    public function recent(int $limit = 100): array
    {
        $limit = max(1, min($limit, 500));
        return $this->db->query(
            "SELECT a.id, a.actor_id, u.name AS actor_name, a.action, a.target_type,
                    a.target_id, a.before_data, a.after_data, a.ip_address,
                    a.result, a.created_at
             FROM audit_logs a
             LEFT JOIN users u ON u.id = a.actor_id
             ORDER BY a.created_at DESC, a.id DESC
             LIMIT {$limit}"
        )->fetchAll(PDO::FETCH_ASSOC);
    }
}
