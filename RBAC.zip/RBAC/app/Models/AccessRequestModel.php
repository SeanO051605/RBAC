<?php

namespace App\Models;

use PDO;

class AccessRequestModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function allForUser(int $userId, string $scope = 'own'): array
    {
        $this->db->exec(
            "UPDATE access_requests SET status = 'expired'
             WHERE status = 'pending' AND expires_at IS NOT NULL AND expires_at <= NOW()"
        );
        $this->db->exec('DELETE FROM user_roles WHERE expires_at IS NOT NULL AND expires_at <= NOW()');
        $sql = 'SELECT DISTINCT ar.*, requester.name AS requester_name, requester.email AS requester_email,
                       approver.name AS approver_name, r.name AS role_name, p.permission_key
                FROM access_requests ar
                JOIN users requester ON requester.id = ar.requester_id
                LEFT JOIN users approver ON approver.id = ar.approver_id
                LEFT JOIN roles r ON r.id = ar.role_id
                LEFT JOIN permissions p ON p.id = ar.permission_id';
        if ($scope === 'team') {
            $sql .= ' JOIN team_members requester_team ON requester_team.user_id = requester.id
                      JOIN team_members reviewer_team ON reviewer_team.team_id = requester_team.team_id
                          AND reviewer_team.user_id = :reviewer_id';
        } elseif ($scope !== 'all') {
            $sql .= ' WHERE ar.requester_id = :user_id';
        }
        $sql .= ' ORDER BY ar.created_at DESC';
        $statement = $this->db->prepare($sql);
        $parameters = match ($scope) {
            'all' => [],
            'team' => ['reviewer_id' => $userId],
            default => ['user_id' => $userId],
        };
        $statement->execute($parameters);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function createRoleRequest(int $userId, int $roleId, string $justification): int
    {
        $statement = $this->db->prepare(
            "INSERT INTO access_requests (requester_id, request_type, role_id, justification)
             VALUES (:requester_id, 'role', :role_id, :justification)"
        );
        $statement->execute([
            'requester_id' => $userId,
            'role_id' => $roleId,
            'justification' => trim($justification),
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function createPermissionRequest(
        int $userId,
        int $permissionId,
        string $justification
    ): int {
        $permission = $this->db->prepare('SELECT id FROM permissions WHERE id = :id');
        $permission->execute(['id' => $permissionId]);
        if (!$permission->fetchColumn()) {
            throw new \InvalidArgumentException('Choose a valid permission to request.');
        }

        $pending = $this->db->prepare(
            "SELECT id FROM access_requests
             WHERE requester_id = :user_id AND permission_id = :permission_id
               AND request_type = 'permission' AND status = 'pending'
             LIMIT 1"
        );
        $pending->execute(['user_id' => $userId, 'permission_id' => $permissionId]);
        if ($pending->fetchColumn()) {
            throw new \InvalidArgumentException('You already have a pending request for this permission.');
        }

        $statement = $this->db->prepare(
            "INSERT INTO access_requests (requester_id, request_type, permission_id, justification)
             VALUES (:requester_id, 'permission', :permission_id, :justification)"
        );
        $statement->execute([
            'requester_id' => $userId,
            'permission_id' => $permissionId,
            'justification' => trim($justification),
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function cancel(int $requestId, int $requesterId): bool
    {
        $statement = $this->db->prepare(
            "UPDATE access_requests SET status = 'cancelled'
             WHERE id = :id AND requester_id = :requester_id AND status = 'pending'"
        );
        $statement->execute(['id' => $requestId, 'requester_id' => $requesterId]);

        return $statement->rowCount() === 1;
    }

    public function decide(
        int $requestId,
        int $approverId,
        string $decision,
        string $note,
        ?string $expiresAt,
        string $scope = 'own'
    ): bool
    {
        if (!in_array($decision, ['approved', 'rejected'], true)) {
            throw new \InvalidArgumentException('Unsupported access request decision.');
        }
        if (!in_array($scope, ['own', 'team', 'all'], true)) {
            throw new \InvalidArgumentException('Unsupported access request scope.');
        }

        $this->db->beginTransaction();
        try {
            $scopeJoin = $scope === 'team'
                ? ' JOIN team_members requester_team ON requester_team.user_id = ar.requester_id
                    JOIN team_members reviewer_team ON reviewer_team.team_id = requester_team.team_id
                        AND reviewer_team.user_id = :approver_id'
                : '';
            $scopeCondition = $scope === 'own' ? ' AND ar.requester_id = :approver_id' : '';
            $select = $this->db->prepare(
                "SELECT ar.requester_id, ar.role_id, ar.permission_id, ar.request_type
                 FROM access_requests ar{$scopeJoin}
                 WHERE ar.id = :id AND ar.status = 'pending'
                   AND (ar.expires_at IS NULL OR ar.expires_at > NOW()){$scopeCondition}
                 FOR UPDATE"
            );
            $select->execute($scope === 'team' || $scope === 'own'
                ? ['id' => $requestId, 'approver_id' => $approverId]
                : ['id' => $requestId]);
            $request = $select->fetch(PDO::FETCH_ASSOC);
            if (!$request) {
                $this->db->rollBack();
                return false;
            }

            if ($decision === 'approved' && $request['request_type'] === 'role') {
                throw new \InvalidArgumentException('Account types are assigned through the Admin/Manager approval flow.');
            }
            $expiresAtValue = null;
            if ($decision === 'approved' && $expiresAt !== null && $expiresAt !== '') {
                $utc = new \DateTimeZone('UTC');
                $expiry = \DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $expiresAt, $utc);
                $dateErrors = \DateTimeImmutable::getLastErrors();
                if (
                    !$expiry
                    || ($dateErrors !== false && ($dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0))
                    || $expiry <= new \DateTimeImmutable('now', $utc)
                ) {
                    throw new \InvalidArgumentException('Access expiry must be a future date and time.');
                }
                $expiresAtValue = $expiry->format('Y-m-d H:i:s');
            }

            if ($decision === 'approved' && $request['request_type'] === 'permission') {
                if ($request['permission_id'] === null) {
                    throw new \InvalidArgumentException('This request no longer refers to a valid permission.');
                }
                $this->db->prepare(
                    'INSERT INTO user_permission_overrides
                        (user_id, permission_id, is_granted, assigned_by, expires_at)
                     VALUES (:user_id, :permission_id, 1, :approver_id, :expires_at)
                     ON DUPLICATE KEY UPDATE
                        is_granted = 1,
                        assigned_by = VALUES(assigned_by),
                        expires_at = VALUES(expires_at)'
                )->execute([
                    'user_id' => $request['requester_id'],
                    'permission_id' => $request['permission_id'],
                    'approver_id' => $approverId,
                    'expires_at' => $expiresAtValue,
                ]);
            }

            if ($decision === 'approved' && $request['request_type'] === 'role' && $request['role_id'] !== null) {
                $assign = $this->db->prepare(
                    'INSERT INTO user_roles (user_id, role_id, assigned_by, expires_at)
                     VALUES (:user_id, :role_id, :approver_id, :expires_at)
                     ON DUPLICATE KEY UPDATE
                         expires_at = CASE WHEN expires_at IS NULL THEN NULL ELSE VALUES(expires_at) END,
                         assigned_by = COALESCE(assigned_by, VALUES(assigned_by))'
                );
                $assign->execute([
                    'user_id' => $request['requester_id'],
                    'role_id' => $request['role_id'],
                    'approver_id' => $approverId,
                    'expires_at' => $expiresAtValue,
                ]);
            }

            $update = $this->db->prepare(
                'UPDATE access_requests
                 SET status = :status, approver_id = :approver_id, decision_note = :decision_note,
                     decided_at = NOW(), expires_at = :expires_at
                 WHERE id = :id'
            );
            $update->execute([
                'status' => $decision,
                'approver_id' => $approverId,
                'decision_note' => trim($note) ?: null,
                'expires_at' => $expiresAtValue,
                'id' => $requestId,
            ]);
            $this->db->commit();
            return true;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }
}
