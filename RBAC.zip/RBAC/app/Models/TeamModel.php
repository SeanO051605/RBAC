<?php

namespace App\Models;

use PDO;

class TeamModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function allForUser(int $userId, bool $isAdmin): array
    {
        $sql = 'SELECT t.id, t.name, t.description, t.status, t.created_at, COUNT(DISTINCT tm.user_id) AS member_count
                FROM teams t
                LEFT JOIN team_members tm ON tm.team_id = t.id';
        if (!$isAdmin) {
            $sql .= ' JOIN team_members self ON self.team_id = t.id AND self.user_id = :user_id';
        }
        $sql .= " WHERE t.status = 'active' GROUP BY t.id ORDER BY t.name";
        $statement = $this->db->prepare($sql);
        $statement->execute($isAdmin ? [] : ['user_id' => $userId]);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function members(int $teamId): array
    {
        $statement = $this->db->prepare(
            'SELECT u.id, u.name, u.email, u.role, u.status
             FROM team_members tm JOIN users u ON u.id = tm.user_id
             WHERE tm.team_id = :team_id ORDER BY u.name'
        );
        $statement->execute(['team_id' => $teamId]);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create(string $name, string $description): int
    {
        $statement = $this->db->prepare('INSERT INTO teams (name, description) VALUES (:name, :description)');
        $statement->execute(['name' => trim($name), 'description' => trim($description)]);

        return (int) $this->db->lastInsertId();
    }

    public function update(int $teamId, string $name, string $description): void
    {
        $statement = $this->db->prepare(
            "UPDATE teams SET name = :name, description = :description WHERE id = :id AND status = 'active'"
        );
        $statement->execute(['name' => trim($name), 'description' => trim($description), 'id' => $teamId]);
    }

    public function archive(int $teamId): void
    {
        $statement = $this->db->prepare("UPDATE teams SET status = 'archived' WHERE id = :id");
        $statement->execute(['id' => $teamId]);
    }

    public function addMember(int $teamId, int $userId, int $actorId): void
    {
        $statement = $this->db->prepare(
            'INSERT IGNORE INTO team_members (team_id, user_id, added_by) VALUES (:team_id, :user_id, :actor_id)'
        );
        $statement->execute(['team_id' => $teamId, 'user_id' => $userId, 'actor_id' => $actorId]);
    }

    public function removeMember(int $teamId, int $userId): void
    {
        $statement = $this->db->prepare('DELETE FROM team_members WHERE team_id = :team_id AND user_id = :user_id');
        $statement->execute(['team_id' => $teamId, 'user_id' => $userId]);
    }

    public function assignRole(int $teamId, int $roleId, int $actorId): void
    {
        $statement = $this->db->prepare(
            'INSERT IGNORE INTO team_roles (team_id, role_id, assigned_by)
             VALUES (:team_id, :role_id, :actor_id)'
        );
        $statement->execute(['team_id' => $teamId, 'role_id' => $roleId, 'actor_id' => $actorId]);
    }

    public function revokeRole(int $teamId, int $roleId): void
    {
        $statement = $this->db->prepare('DELETE FROM team_roles WHERE team_id = :team_id AND role_id = :role_id');
        $statement->execute(['team_id' => $teamId, 'role_id' => $roleId]);
    }

    public function roles(int $teamId): array
    {
        $statement = $this->db->prepare(
            'SELECT r.id, r.name, r.slug FROM team_roles tr
             JOIN roles r ON r.id = tr.role_id
             WHERE tr.team_id = :team_id
               AND (tr.expires_at IS NULL OR tr.expires_at > NOW())
             ORDER BY r.name'
        );
        $statement->execute(['team_id' => $teamId]);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
}
