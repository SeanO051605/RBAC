<?php
namespace App\Models;

use PDO;
use Throwable;

class RegisterModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function registerFromInvitation(string $token, string $password): array
    {
        $this->db->beginTransaction();

        try {
            $invitationStatement = $this->db->prepare(
                "SELECT i.id, i.email, i.name, i.role_id, r.slug AS role_slug
                 FROM invitations i
                 JOIN roles r ON r.id = i.role_id AND r.status = 'active'
                 WHERE i.token_hash = :token_hash
                   AND i.status = 'pending'
                   AND i.expires_at > NOW()
                 LIMIT 1
                 FOR UPDATE"
            );
            $invitationStatement->execute(['token_hash' => hash('sha256', $token)]);
            $invitation = $invitationStatement->fetch(PDO::FETCH_ASSOC);

            if (!$invitation) {
                throw new \RuntimeException('This invitation is invalid, expired, or already used.');
            }

            $existingUser = $this->db->prepare('SELECT 1 FROM users WHERE email = :email LIMIT 1');
            $existingUser->execute(['email' => $invitation['email']]);
            if ($existingUser->fetchColumn()) {
                throw new \RuntimeException('An account already exists for this invitation.');
            }

            $createUser = $this->db->prepare(
                "INSERT INTO users (name, email, password, role, status, email_verified_at)
                 VALUES (:name, :email, :password, :role, 'invited', NOW())"
            );
            $createUser->execute([
                'name' => $invitation['name'],
                'email' => $invitation['email'],
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role' => $invitation['role_slug'],
            ]);
            $userId = (int) $this->db->lastInsertId();

            $assignRole = $this->db->prepare(
                'INSERT INTO user_roles (user_id, role_id, assigned_by)
                 VALUES (:user_id, :role_id, NULL)'
            );
            $assignRole->execute([
                'user_id' => $userId,
                'role_id' => $invitation['role_id'],
            ]);

            $markAccepted = $this->db->prepare(
                "UPDATE invitations SET status = 'accepted', accepted_at = NOW()
                 WHERE id = :id AND status = 'pending'"
            );
            $markAccepted->execute(['id' => $invitation['id']]);
            if ($markAccepted->rowCount() !== 1) {
                throw new \RuntimeException('This invitation has already been used.');
            }

            $userStatement = $this->db->prepare(
                'SELECT id, name, email, role, status, created_at FROM users WHERE id = :id'
            );
            $userStatement->execute(['id' => $userId]);
            $user = $userStatement->fetch(PDO::FETCH_ASSOC);
            if (!$user) {
                throw new \RuntimeException('The registered account could not be loaded.');
            }

            $this->db->commit();

            return $user;
        } catch (Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $error;
        }
    }
}
