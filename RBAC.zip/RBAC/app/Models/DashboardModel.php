<?php

namespace App\Models;

class DashboardModel
{
    private UserModel $users;
    private AuthorizationModel $authorization;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->authorization = new AuthorizationModel();
    }

    public function grantableRoles(array $actor): array
    {
        return array_values(array_filter(
            $this->allRoles(),
            fn(array $role): bool => $this->canGrantRole($actor, (int) $role['id'])
        ));
    }

    public function allUsers(): array
    {
        return $this->users->all();
    }

    public function pendingAccountsForApproval(array $approver): array
    {
        if ($this->hasRole((int) $approver['id'], 'admin') && $this->can($approver, 'users.manage', [])) {
            return $this->users->pendingForApproval(['manager', 'admin']);
        }

        if ($this->hasRole((int) $approver['id'], 'manager') && $this->can($approver, 'users.approve', [])) {
            return $this->users->pendingForApproval(['employee']);
        }

        return [];
    }

    public function findUser(int $id): ?array
    {
        return $this->users->findById($id);
    }

    public function updateProfile(int $id, string $name): void
    {
        $this->users->updateProfile($id, $name);
    }

    public function updateRole(int $id, string $role): void
    {
        $this->users->updateRole($id, $role);
    }

    public function updateStatus(int $id, string $status): void
    {
        $this->users->updateStatus($id, $status);
    }

    public function approveAccount(int $id): bool
    {
        return $this->users->approveAccount($id);
    }

    public function emailExists(string $email, ?int $exceptId = null): bool
    {
        return $this->users->emailExists($email, $exceptId);
    }

    public function createUser(
        string $name,
        string $email,
        string $password,
        string $role,
        string $status,
        bool $mustChangePassword = false
    ): array
    {
        return $this->users->create($name, $email, $password, $role, $status, $mustChangePassword);
    }

    public function changePassword(int $id, string $password): void
    {
        $this->users->changePassword($id, $password);
    }

    public function updateUser(
        int $id,
        string $name,
        string $email,
        string $status,
        ?string $password = null
    ): void {
        $this->users->updateUser($id, $name, $email, $status, $password);
    }

    public function deleteUser(int $id): void
    {
        $this->users->delete($id);
    }

    public function countActiveAdmins(): int
    {
        return $this->users->countActiveAdmins();
    }

    public function hasRole(int $userId, string $roleSlug): bool
    {
        return $this->users->hasRole($userId, $roleSlug);
    }

    public function canGrantRole(array $actor, int $roleId): bool
    {
        $role = $this->findRoleById($roleId);
        if (!$role || $role['status'] !== 'active') {
            return false;
        }
        if (!in_array($role['slug'], ['manager', 'employee'], true)) {
            return false;
        }
        if ($this->hasRole((int) $actor['id'], 'admin') && $this->can($actor, 'roles.assign', [])) {
            return true;
        }
        return $role['slug'] === 'employee'
            && $this->hasRole((int) $actor['id'], 'manager')
            && $this->can($actor, 'users.invite', []);
    }

    public function canApproveAccount(array $approver, array $account): bool
    {
        if (($account['role'] ?? '') === 'manager' || ($account['role'] ?? '') === 'admin') {
            return $this->can($approver, 'users.manage', []);
        }

        return ($account['role'] ?? '') === 'employee'
            && $this->hasRole((int) $approver['id'], 'manager')
            && $this->can($approver, 'users.approve', []);
    }

    public function reset(): void
    {
        $this->users->reset();
    }

    public function can(array $user, string $permission, array $roles): bool
    {
        $permissionMap = [
            'dashboard.view' => 'dashboard:read',
            'profile.edit' => 'profile:update',
            'reports.view' => 'reports:view',
            'team.manage' => 'teams:update',
            'teams.create' => 'teams:create',
            'teams.delete' => 'teams:delete',
            'users.view' => 'users:read',
            'users.manage' => 'users:update',
            'users.update' => 'users:update',
            'users.invite' => 'users:invite',
            'users.approve' => 'users:approve',
            'teams.read' => 'teams:read',
            'roles.read' => 'roles:read',
            'permissions.read' => 'permissions:read',
            'roles.create' => 'roles:create',
            'roles.update' => 'roles:update',
            'roles.delete' => 'roles:delete',
            'roles.assign' => 'roles:assign',
            'requests.read' => 'requests:read',
            'requests.create' => 'requests:create',
            'requests.approve' => 'requests:approve',
            'tasks.read' => 'tasks:read',
            'notifications.read' => 'notifications:read',
            'audit_logs.read' => 'audit_logs:read',
            'settings.read' => 'settings:read',
            'settings.manage' => 'settings:update',
        ];

        return isset($permissionMap[$permission])
            && $this->authorization->allows((int) $user['id'], $permissionMap[$permission]);
    }

    public function allRoles(): array
    {
        return $this->users->allRoles();
    }

    public function findRoleById(int $id): ?array
    {
        return $this->users->findRoleById($id);
    }

    public function findRoleBySlug(string $slug): ?array
    {
        return $this->users->findRoleBySlug($slug);
    }

    public function createRole(string $name, string $slug, string $description): int
    {
        return $this->users->createRole($name, $slug, $description);
    }

    public function updateRoleDefinition(int $id, string $name, string $description, array $permissionIds): void
    {
        $this->users->updateRoleDefinition($id, $name, $description, $permissionIds);
    }

    public function deleteRole(int $id): void
    {
        $this->users->deleteRole($id);
    }

    public function allPermissions(): array
    {
        return $this->users->allPermissions();
    }

    public function rolePermissions(int $id): array
    {
        return $this->users->rolePermissions($id);
    }

    public function roleMemberCount(int $id): int
    {
        return $this->users->roleMemberCount($id);
    }

    public function roleUsers(int $id): array
    {
        return $this->users->roleUsers($id);
    }

    public function rolesForUser(int $userId): array
    {
        return $this->users->rolesForUser($userId);
    }

    public function permissionsForUser(int $userId): array
    {
        return $this->authorization->permissionsForUser($userId);
    }

    public function setUserPermissions(int $userId, array $permissionIds, int $assignedBy): void
    {
        $this->authorization->setUserPermissions($userId, $permissionIds, $assignedBy);
    }

    public function assignUserRole(int $userId, int $roleId, int $actorId): void
    {
        $this->users->assignUserRole($userId, $roleId, $actorId);
    }

    public function revokeUserRole(int $userId, int $roleId): void
    {
        $this->users->revokeUserRole($userId, $roleId);
    }
}
