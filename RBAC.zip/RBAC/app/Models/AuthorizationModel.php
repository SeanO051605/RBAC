<?php

namespace App\Models;

use PDO;

class AuthorizationModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function permissionsForUser(int $userId): array
    {
        $permissions = array_fill_keys(
            $this->inheritedPermissionsForUser($userId),
            true
        );
        $overrides = $this->db->prepare(
            'SELECT p.permission_key, upo.is_granted
             FROM user_permission_overrides upo
             JOIN permissions p ON p.id = upo.permission_id
             WHERE upo.user_id = :user_id
               AND (upo.expires_at IS NULL OR upo.expires_at > NOW())'
        );
        $overrides->execute(['user_id' => $userId]);
        foreach ($overrides->fetchAll(PDO::FETCH_ASSOC) as $override) {
            if ((int) $override['is_granted'] === 1) {
                $permissions[$override['permission_key']] = true;
            } else {
                unset($permissions[$override['permission_key']]);
            }
        }

        return array_keys($permissions);
    }

    public function setUserPermissions(int $userId, array $permissionIds, int $assignedBy): void
    {
        $allPermissions = $this->db->query(
            'SELECT id, permission_key FROM permissions'
        )->fetchAll(PDO::FETCH_KEY_PAIR);
        $selectedIds = [];
        foreach ($permissionIds as $permissionId) {
            if (!is_int($permissionId) || !isset($allPermissions[$permissionId])) {
                throw new \InvalidArgumentException('One or more selected permissions are invalid.');
            }
            $selectedIds[$permissionId] = true;
        }

        $inheritedPermissions = array_fill_keys($this->inheritedPermissionsForUser($userId), true);
        $this->db->beginTransaction();
        try {
            $this->db->prepare('DELETE FROM user_permission_overrides WHERE user_id = :user_id')
                ->execute(['user_id' => $userId]);
            $insert = $this->db->prepare(
                'INSERT INTO user_permission_overrides (user_id, permission_id, is_granted, assigned_by)
                 VALUES (:user_id, :permission_id, :is_granted, :assigned_by)'
            );
            foreach ($allPermissions as $permissionId => $permissionKey) {
                $permissionId = (int) $permissionId;
                $selected = isset($selectedIds[$permissionId]);
                $inherited = isset($inheritedPermissions[$permissionKey]);
                if ($selected !== $inherited) {
                    $insert->execute([
                        'user_id' => $userId,
                        'permission_id' => $permissionId,
                        'is_granted' => $selected ? 1 : 0,
                        'assigned_by' => $assignedBy,
                    ]);
                }
            }
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function allows(int $userId, string $permission): bool
    {
        return in_array($permission, $this->permissionsForUser($userId), true);
    }

    private function inheritedPermissionsForUser(int $userId): array
    {
        $statement = $this->db->prepare(
            "SELECT DISTINCT p.permission_key
             FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             JOIN roles r ON r.id = rp.role_id AND r.status = 'active'
             JOIN user_roles ur ON ur.role_id = r.id
             WHERE ur.user_id = :user_id AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
             UNION
             SELECT DISTINCT p.permission_key
             FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             JOIN roles r ON r.id = rp.role_id AND r.status = 'active'
             JOIN team_roles tr ON tr.role_id = r.id
             JOIN team_members tm ON tm.team_id = tr.team_id
             JOIN teams t ON t.id = tm.team_id AND t.status = 'active'
             WHERE tm.user_id = :team_user_id AND (tr.expires_at IS NULL OR tr.expires_at > NOW())"
        );
        $statement->execute(['user_id' => $userId, 'team_user_id' => $userId]);

        return array_column($statement->fetchAll(PDO::FETCH_ASSOC), 'permission_key');
    }

    public function rolesForUser(int $userId): array
    {
        $statement = $this->db->prepare(
            "SELECT r.id, r.name, r.slug, r.type, MAX(ur.user_id IS NOT NULL) AS is_direct
             FROM roles r
             LEFT JOIN user_roles ur ON ur.role_id = r.id AND ur.user_id = :user_id
                 AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
             LEFT JOIN team_roles tr ON tr.role_id = r.id
                 AND (tr.expires_at IS NULL OR tr.expires_at > NOW())
             LEFT JOIN team_members tm ON tm.team_id = tr.team_id AND tm.user_id = :team_user_id
             LEFT JOIN teams t ON t.id = tm.team_id AND t.status = 'active'
             WHERE r.status = 'active' AND (ur.user_id IS NOT NULL OR t.id IS NOT NULL)
             GROUP BY r.id, r.name, r.slug, r.type
             ORDER BY r.name"
        );
        $statement->execute(['user_id' => $userId, 'team_user_id' => $userId]);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function assignRoles(int $userId, array $roleIds, ?int $assignedBy = null): void
    {
        $this->db->beginTransaction();
        try {
            $delete = $this->db->prepare('DELETE FROM user_roles WHERE user_id = :user_id');
            $delete->execute(['user_id' => $userId]);

            $insert = $this->db->prepare(
                'INSERT INTO user_roles (user_id, role_id, assigned_by) VALUES (:user_id, :role_id, :assigned_by)'
            );
            foreach (array_unique(array_map('intval', $roleIds)) as $roleId) {
                $insert->execute([
                    'user_id' => $userId,
                    'role_id' => $roleId,
                    'assigned_by' => $assignedBy,
                ]);
            }

            $this->db->commit();
        } catch (\Throwable $error) {
            $this->db->rollBack();
            throw $error;
        }
    }
}
