<?php

namespace App\Models;

use PDO;

class UserModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function all(): array
    {
        return $this->db->query(
            'SELECT id, name, email, role, status, created_at FROM users ORDER BY id'
        )->fetchAll();
    }

    public function pendingForApproval(array $roleSlugs): array
    {
        $roleSlugs = array_values(array_intersect($roleSlugs, ['admin', 'manager', 'employee']));
        if ($roleSlugs === []) {
            return [];
        }

        $placeholders = implode(', ', array_fill(0, count($roleSlugs), '?'));
        $statement = $this->db->prepare(
            "SELECT id, name, email, role, status, created_at
             FROM users
             WHERE status = 'invited' AND role IN ({$placeholders})
             ORDER BY created_at, id"
        );
        $statement->execute($roleSlugs);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findByEmail(string $email): ?array
    {
        $statement = $this->db->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $statement->execute(['email' => strtolower(trim($email))]);

        return $statement->fetch() ?: null;
    }

    public function emailExists(string $email, ?int $exceptId = null): bool
    {
        $sql = 'SELECT 1 FROM users WHERE email = :email';
        $parameters = ['email' => strtolower(trim($email))];

        if ($exceptId !== null) {
            $sql .= ' AND id != :id';
            $parameters['id'] = $exceptId;
        }

        $statement = $this->db->prepare($sql . ' LIMIT 1');
        $statement->execute($parameters);

        return (bool) $statement->fetchColumn();
    }

    public function findById(int $id): ?array
    {
        $statement = $this->db->prepare(
            'SELECT id, name, email, role, status, must_change_password, created_at FROM users WHERE id = :id LIMIT 1'
        );
        $statement->execute(['id' => $id]);

        return $statement->fetch() ?: null;
    }

    public function authenticate(string $email, string $password): ?array
    {
        $statement = $this->db->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
        $statement->execute(['email' => strtolower(trim($email))]);
        $user = $statement->fetch();

        $email = strtolower(trim($email));
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $lockout = $this->db->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE attempted_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)
               AND (email = :email OR ip_address = :ip_address)
               AND succeeded = 0'
        );
        $lockout->execute(['email' => $email, 'ip_address' => $ipAddress]);

        if ((int) $lockout->fetchColumn() >= 5) {
            $this->recordLoginAttempt($email, false);
            return null;
        }

        if (!$user || $user['status'] !== 'active' || !password_verify($password, $user['password'])) {
            $this->recordLoginAttempt($email, false);
            return null;
        }

        $this->recordLoginAttempt($email, true);
        $this->db->prepare('UPDATE users SET last_login_at = NOW() WHERE id = :id')
            ->execute(['id' => $user['id']]);
        unset($user['password']);
        return $user;
    }

    private function recordLoginAttempt(string $email, bool $succeeded): void
    {
        $statement = $this->db->prepare(
            'INSERT INTO login_attempts (email, ip_address, succeeded)
             VALUES (:email, :ip_address, :succeeded)'
        );
        $statement->execute([
            'email' => $email,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'succeeded' => $succeeded ? 1 : 0,
        ]);
    }

    public function create(
        string $name,
        string $email,
        string $password,
        string $role = 'employee',
        string $status = 'active',
        bool $mustChangePassword = false
    ): array {
        $statement = $this->db->prepare(
            'INSERT INTO users (name, email, password, role, status, must_change_password)
             VALUES (:name, :email, :password, :role, :status, :must_change_password)'
        );
        $this->db->beginTransaction();
        try {
            $statement->execute([
                'name' => trim($name),
                'email' => strtolower(trim($email)),
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role' => $role,
                'status' => $status,
                'must_change_password' => $mustChangePassword ? 1 : 0,
            ]);
            $userId = (int) $this->db->lastInsertId();
            $roleStatement = $this->db->prepare("SELECT id FROM roles WHERE slug = :slug AND status = 'active'");
            $roleStatement->execute(['slug' => $role]);
            $roleId = $roleStatement->fetchColumn();
            if ($roleId) {
                $this->db->prepare(
                    'INSERT INTO user_roles (user_id, role_id) VALUES (:user_id, :role_id)'
                )->execute(['user_id' => $userId, 'role_id' => $roleId]);
            }
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }

        return $this->findById($userId)
            ?? throw new \RuntimeException('Created user could not be loaded.');
    }

    public function changePassword(int $id, string $password): void
    {
        $existing = $this->db->prepare(
            "SELECT password FROM users WHERE id = :id AND status = 'active' LIMIT 1"
        );
        $existing->execute(['id' => $id]);
        $passwordHash = $existing->fetchColumn();
        if ($passwordHash === false) {
            throw new \RuntimeException('The account could not be found.');
        }
        if (password_verify($password, $passwordHash)) {
            throw new \InvalidArgumentException('Choose a password different from your temporary password.');
        }

        $statement = $this->db->prepare(
            'UPDATE users SET password = :password, must_change_password = 0 WHERE id = :id'
        );
        $statement->execute([
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $id,
        ]);
        if ($statement->rowCount() !== 1) {
            throw new \RuntimeException('The password could not be updated.');
        }
    }

    public function updateProfile(int $id, string $name): void
    {
        $statement = $this->db->prepare('UPDATE users SET name = :name WHERE id = :id');
        $statement->execute(['name' => trim($name), 'id' => $id]);
    }

    public function updateRole(int $id, string $role): void
    {
        $statement = $this->db->prepare('UPDATE users SET role = :role WHERE id = :id');
        $statement->execute(['role' => $role, 'id' => $id]);
    }

    public function updateStatus(int $id, string $status): void
    {
        $statement = $this->db->prepare('UPDATE users SET status = :status WHERE id = :id');
        $statement->execute(['status' => $status, 'id' => $id]);
    }

    public function approveAccount(int $id): bool
    {
        $statement = $this->db->prepare(
            "UPDATE users SET status = 'active'
             WHERE id = :id AND status = 'invited'"
        );
        $statement->execute(['id' => $id]);

        return $statement->rowCount() === 1;
    }

    public function updateUser(
        int $id,
        string $name,
        string $email,
        string $status,
        ?string $password = null
    ): void {
        $sql = 'UPDATE users SET name = :name, email = :email, status = :status';
        $parameters = [
            'name' => trim($name),
            'email' => strtolower(trim($email)),
            'status' => $status,
            'id' => $id,
        ];

        if ($password !== null && $password !== '') {
            $sql .= ', password = :password, must_change_password = 1';
            $parameters['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $statement = $this->db->prepare($sql . ' WHERE id = :id');
        $statement->execute($parameters);
    }

    public function delete(int $id): void
    {
        $this->db->beginTransaction();
        try {
            $this->db->prepare('UPDATE invitations SET invited_by = NULL WHERE invited_by = :id')
                ->execute(['id' => $id]);
            $this->db->prepare('DELETE FROM users WHERE id = :id')->execute(['id' => $id]);
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function countActiveAdmins(): int
    {
        return $this->countActiveUsersWithRole('admin');
    }

    public function countActiveUsersWithRole(string $slug): int
    {
        $statement = $this->db->prepare(
            "SELECT COUNT(DISTINCT u.id)
             FROM users u
             WHERE u.status = 'active'
               AND (
                   EXISTS (
                       SELECT 1 FROM user_roles ur
                       JOIN roles r ON r.id = ur.role_id AND r.slug = :direct_slug AND r.status = 'active'
                       WHERE ur.user_id = u.id AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
                   )
                   OR EXISTS (
                       SELECT 1 FROM team_members tm
                       JOIN teams t ON t.id = tm.team_id AND t.status = 'active'
                       JOIN team_roles tr ON tr.team_id = tm.team_id
                       JOIN roles r ON r.id = tr.role_id AND r.slug = :team_slug AND r.status = 'active'
                       WHERE tm.user_id = u.id AND (tr.expires_at IS NULL OR tr.expires_at > NOW())
                   )
               )"
        );
        $statement->execute(['direct_slug' => $slug, 'team_slug' => $slug]);

        return (int) $statement->fetchColumn();
    }

    public function countPendingInvitationsForRole(string $slug): int
    {
        $statement = $this->db->prepare(
            "SELECT COUNT(*)
             FROM invitations i
             JOIN roles r ON r.id = i.role_id AND r.slug = :slug
             WHERE i.status = 'pending' AND i.expires_at > NOW()"
        );
        $statement->execute(['slug' => $slug]);

        return (int) $statement->fetchColumn();
    }

    public function hasRole(int $userId, string $roleSlug): bool
    {
        $statement = $this->db->prepare(
            "SELECT 1
             FROM roles r
             WHERE r.slug = :slug AND r.status = 'active'
               AND (
                   EXISTS (
                       SELECT 1 FROM user_roles ur
                       WHERE ur.user_id = :user_id AND ur.role_id = r.id
                         AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
                   )
                   OR EXISTS (
                       SELECT 1 FROM team_members tm
                       JOIN teams t ON t.id = tm.team_id AND t.status = 'active'
                       JOIN team_roles tr ON tr.team_id = tm.team_id AND tr.role_id = r.id
                       WHERE tm.user_id = :team_user_id AND (tr.expires_at IS NULL OR tr.expires_at > NOW())
                   )
               )
             LIMIT 1"
        );
        $statement->execute(['slug' => $roleSlug, 'user_id' => $userId, 'team_user_id' => $userId]);

        return (bool) $statement->fetchColumn();
    }

    public function allRoles(): array
    {
        return $this->db->query(
            "SELECT id, name, slug, description, type, status, is_protected, created_at
             FROM roles
             WHERE slug IN ('admin', 'manager', 'employee') AND status = 'active'
             ORDER BY FIELD(slug, 'admin', 'manager', 'employee')"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findRoleById(int $id): ?array
    {
        $statement = $this->db->prepare(
            'SELECT id, name, slug, description, type, status, is_protected FROM roles WHERE id = :id LIMIT 1'
        );
        $statement->execute(['id' => $id]);

        return $statement->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function findRoleBySlug(string $slug): ?array
    {
        $statement = $this->db->prepare(
            "SELECT id, name, slug, description, type, status FROM roles WHERE slug = :slug AND status = 'active' LIMIT 1"
        );
        $statement->execute(['slug' => $slug]);

        return $statement->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function roleUsers(int $roleId): array
    {
        $statement = $this->db->prepare(
            'SELECT u.id, u.name, u.email
             FROM user_roles ur JOIN users u ON u.id = ur.user_id
             WHERE ur.role_id = :role_id ORDER BY u.name'
        );
        $statement->execute(['role_id' => $roleId]);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function rolesForUser(int $userId): array
    {
        $statement = $this->db->prepare(
            'SELECT r.id, r.name, r.slug, r.type
             FROM user_roles ur JOIN roles r ON r.id = ur.role_id
             WHERE ur.user_id = :user_id AND r.status = \'active\'
               AND r.slug IN (\'admin\', \'manager\', \'employee\')
             ORDER BY FIELD(r.slug, \'admin\', \'manager\', \'employee\')'
        );
        $statement->execute(['user_id' => $userId]);

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function createRole(string $name, string $slug, string $description): int
    {
        throw new \RuntimeException('Only Admin, Manager, and Employee account types are supported.');
    }

    public function updateRoleDefinition(int $id, string $name, string $description, array $permissionIds): void
    {
        $role = $this->findRoleById($id);
        if (!$role || $role['type'] !== 'custom' || (int) $role['is_protected'] === 1) {
            throw new \RuntimeException('System roles cannot be modified.');
        }

        $this->db->beginTransaction();
        try {
            $this->db->prepare('UPDATE roles SET name = :name, description = :description WHERE id = :id')
                ->execute(['name' => trim($name), 'description' => trim($description), 'id' => $id]);
            $this->db->prepare('DELETE FROM role_permissions WHERE role_id = :role_id')
                ->execute(['role_id' => $id]);
            $insert = $this->db->prepare(
                'INSERT INTO role_permissions (role_id, permission_id) VALUES (:role_id, :permission_id)'
            );
            foreach (array_unique(array_map('intval', $permissionIds)) as $permissionId) {
                $insert->execute(['role_id' => $id, 'permission_id' => $permissionId]);
            }
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function deleteRole(int $id): void
    {
        $role = $this->findRoleById($id);
        if (!$role || $role['type'] !== 'custom' || (int) $role['is_protected'] === 1) {
            throw new \RuntimeException('System roles cannot be deleted.');
        }

        foreach ([
            'user_roles' => 'users',
            'team_roles' => 'teams',
        ] as $table => $assignmentType) {
            $statement = $this->db->prepare("SELECT COUNT(*) FROM {$table} WHERE role_id = :id");
            $statement->execute(['id' => $id]);
            if ((int) $statement->fetchColumn() > 0) {
                throw new \RuntimeException("Remove this role from assigned {$assignmentType} before archiving it.");
            }
        }

        $pending = $this->db->prepare(
            "SELECT COUNT(*) FROM invitations
             WHERE role_id = :id AND status = 'pending' AND expires_at > NOW()"
        );
        $pending->execute(['id' => $id]);
        if ((int) $pending->fetchColumn() > 0) {
            throw new \RuntimeException('Cancel pending invitations for this role before archiving it.');
        }

        $this->db->prepare("UPDATE roles SET status = 'archived' WHERE id = :id")->execute(['id' => $id]);
    }

    public function allPermissions(): array
    {
        return $this->db->query(
            'SELECT id, permission_key, category, description FROM permissions ORDER BY category, permission_key'
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function rolePermissions(int $roleId): array
    {
        $statement = $this->db->prepare(
            'SELECT permission_id FROM role_permissions WHERE role_id = :role_id'
        );
        $statement->execute(['role_id' => $roleId]);

        return array_map('intval', array_column($statement->fetchAll(PDO::FETCH_ASSOC), 'permission_id'));
    }

    public function roleMemberCount(int $roleId): int
    {
        $statement = $this->db->prepare('SELECT COUNT(*) FROM user_roles WHERE role_id = :role_id');
        $statement->execute(['role_id' => $roleId]);

        return (int) $statement->fetchColumn();
    }

    public function assignUserRole(int $userId, int $roleId, int $assignedBy): void
    {
        $user = $this->findById($userId);
        $role = $this->findRoleById($roleId);
        if (
            !$user
            || !$role
            || $role['status'] !== 'active'
            || !in_array($role['slug'], ['admin', 'manager', 'employee'], true)
        ) {
            throw new \RuntimeException('User or active role was not found.');
        }

        $this->db->beginTransaction();
        try {
            $delete = $this->db->prepare('DELETE FROM user_roles WHERE user_id = :user_id');
            $delete->execute(['user_id' => $userId]);

            $statement = $this->db->prepare(
            'INSERT INTO user_roles (user_id, role_id, assigned_by)
             VALUES (:user_id, :role_id, :assigned_by)'
            );
            $statement->execute([
                'user_id' => $userId,
                'role_id' => $roleId,
                'assigned_by' => $assignedBy,
            ]);
            $this->syncLegacyRole($userId);
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function revokeUserRole(int $userId, int $roleId): void
    {
        $role = $this->findRoleById($roleId);
        throw new \RuntimeException('Each account must have one of the supported account types.');
    }

    private function syncLegacyRole(int $userId): void
    {
        $statement = $this->db->prepare(
            "SELECT r.slug
             FROM user_roles ur JOIN roles r ON r.id = ur.role_id
             WHERE ur.user_id = :user_id AND r.slug IN ('admin', 'manager', 'employee')
             ORDER BY FIELD(r.slug, 'admin', 'manager', 'employee')
             LIMIT 1"
        );
        $statement->execute(['user_id' => $userId]);
        $slug = $statement->fetchColumn() ?: 'employee';
        $this->db->prepare('UPDATE users SET role = :role WHERE id = :id')
            ->execute(['role' => $slug, 'id' => $userId]);
    }

    public function reset(): void
    {
        $this->db->beginTransaction();
        try {
            $this->db->exec(
                "UPDATE invitations
                 SET invited_by = NULL, status = IF(status = 'pending', 'cancelled', status)"
            );
            $this->db->exec('DELETE FROM teams');
            $this->db->exec('DELETE FROM users');
            $statement = $this->db->prepare(
                'INSERT INTO users (id, name, email, password, role, status, created_at)
                 VALUES (:id, :name, :email, :password, :role, :status, :created_at)'
            );

            foreach ($this->defaultUsers() as $user) {
                $statement->execute($user);
            }
            $this->db->exec(
                'INSERT INTO user_roles (user_id, role_id)
                 SELECT u.id, r.id FROM users u JOIN roles r ON r.slug = u.role'
            );
            $this->seedDemoRecords();

            $this->db->commit();
        } catch (\Throwable $error) {
            $this->db->rollBack();
            throw $error;
        }
    }

    private function defaultUsers(): array
    {
        return [
            [
                'id' => 1,
                'name' => 'Ada Admin',
                'email' => 'admin@rbac.test',
                'password' => password_hash('Admin@123', PASSWORD_DEFAULT),
                'role' => 'admin',
                'status' => 'active',
                'created_at' => '2024-01-15 09:30:00',
            ],
            [
                'id' => 2,
                'name' => 'Mia Manager',
                'email' => 'manager@rbac.test',
                'password' => password_hash('Manager@123', PASSWORD_DEFAULT),
                'role' => 'manager',
                'status' => 'active',
                'created_at' => '2024-02-01 10:15:00',
            ],
            [
                'id' => 3,
                'name' => 'Uli User',
                'email' => 'user@rbac.test',
                'password' => password_hash('User@1234', PASSWORD_DEFAULT),
                'role' => 'employee',
                'status' => 'active',
                'created_at' => '2024-03-10 08:45:00',
            ],
            [
                'id' => 4,
                'name' => 'Eli Chen',
                'email' => 'eli.chen@rbac.test',
                'password' => password_hash('Employee@1234', PASSWORD_DEFAULT),
                'role' => 'employee',
                'status' => 'invited',
                'created_at' => '2024-04-04 09:00:00',
            ],
            [
                'id' => 5,
                'name' => 'Noah Patel',
                'email' => 'noah.patel@rbac.test',
                'password' => password_hash('Manager@1234', PASSWORD_DEFAULT),
                'role' => 'manager',
                'status' => 'invited',
                'created_at' => '2024-04-05 09:00:00',
            ],
        ];
    }

    private function seedDemoRecords(): void
    {
        $this->db->exec(
            "INSERT INTO teams (name, description) VALUES
             ('Product Engineering', 'Builds and maintains the GateKeeper platform.'),
             ('Customer Success', 'Supports customer onboarding and account health.')"
        );
        $teamIds = $this->db->query(
            "SELECT name, id FROM teams
             WHERE name IN ('Product Engineering', 'Customer Success')"
        )->fetchAll(PDO::FETCH_KEY_PAIR);
        $member = $this->db->prepare(
            'INSERT INTO team_members (team_id, user_id, added_by)
             VALUES (:team_id, :user_id, :added_by)'
        );
        foreach ([
            ['Product Engineering', 2, 1],
            ['Product Engineering', 3, 2],
            ['Product Engineering', 4, 2],
            ['Customer Success', 2, 1],
            ['Customer Success', 3, 2],
        ] as [$teamName, $userId, $addedBy]) {
            $member->execute([
                'team_id' => $teamIds[$teamName],
                'user_id' => $userId,
                'added_by' => $addedBy,
            ]);
        }

        $permission = $this->db->prepare(
            "SELECT id FROM permissions WHERE permission_key = 'teams:create' LIMIT 1"
        );
        $permission->execute();
        $permissionId = $permission->fetchColumn();
        if ($permissionId === false) {
            throw new \RuntimeException('The demo access-request permission is missing.');
        }
        $request = $this->db->prepare(
            "INSERT INTO access_requests
                (requester_id, request_type, permission_id, justification)
             VALUES (3, 'permission', :permission_id, :justification)"
        );
        $request->execute([
            'permission_id' => $permissionId,
            'justification' => 'I need to create a project team for the next product release.',
        ]);
        $requestId = (string) $this->db->lastInsertId();

        $role = $this->db->prepare(
            "SELECT id FROM roles WHERE slug = 'employee' AND status = 'active' LIMIT 1"
        );
        $role->execute();
        $roleId = $role->fetchColumn();
        if ($roleId === false) {
            throw new \RuntimeException('The demo invitation account type is missing.');
        }
        $this->db->prepare(
            "INSERT INTO invitations (email, name, token_hash, role_id, invited_by, expires_at)
             VALUES (:email, :name, :token_hash, :role_id, 1, DATE_ADD(NOW(), INTERVAL 7 DAY))"
        )->execute([
            'email' => 'jordan.lee@rbac.test',
            'name' => 'Jordan Lee',
            'token_hash' => hash('sha256', bin2hex(random_bytes(32))),
            'role_id' => $roleId,
        ]);

        if ((int) $this->db->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn() === 0) {
            $audit = $this->db->prepare(
                'INSERT INTO audit_logs (actor_id, action, target_type, target_id, after_data)
                 VALUES (:actor_id, :action, :target_type, :target_id, :after_data)'
            );
            foreach ([
                [1, 'user.invited', 'invitation', null, ['email' => 'jordan.lee@rbac.test', 'role' => 'employee']],
                [2, 'team.created', 'team', (string) $teamIds['Product Engineering'], ['name' => 'Product Engineering']],
                [3, 'access_request.created', 'access_request', $requestId, ['permission' => 'teams:create']],
            ] as [$actorId, $action, $targetType, $targetId, $after]) {
                $audit->execute([
                    'actor_id' => $actorId,
                    'action' => $action,
                    'target_type' => $targetType,
                    'target_id' => $targetId,
                    'after_data' => json_encode($after, JSON_THROW_ON_ERROR),
                ]);
            }
        }
    }
}
