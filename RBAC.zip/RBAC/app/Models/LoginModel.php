<?php

namespace App\Models;

class LoginModel
{
    private UserModel $users;

    public function __construct()
    {
        $this->users = new UserModel();
    }

    public function authenticate(string $email, string $password): ?array
    {
        return $this->users->authenticate($email, $password);
    }
}
