<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Change password · GateKeeper</title>
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/public/styles.css">
</head>
<body>
    <main class="auth-card-side">
        <form class="auth-card" method="post" action="<?= htmlspecialchars($basePath) ?>/change-password">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
            <h2>Change your password</h2>
            <p class="sub">Your account was created with a temporary password. Set a new password to continue.</p>
            <?php if ($error !== ''): ?>
                <div class="alert error show" role="alert"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <div class="field">
                <label for="password">New password</label>
                <input id="password" name="password" type="password" maxlength="128" autocomplete="new-password" required>
                <small>Include at least one uppercase letter, one lowercase letter, and one number.</small>
            </div>
            <div class="field">
                <label for="password_confirmation">Confirm new password</label>
                <input id="password_confirmation" name="password_confirmation" type="password" maxlength="128" autocomplete="new-password" required>
            </div>
            <button class="btn" type="submit">Update password</button>
        </form>
    </main>
</body>
</html>
