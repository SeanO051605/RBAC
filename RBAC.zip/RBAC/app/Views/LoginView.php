<?php
$year = date('Y');
$error = $error ?? '';
$notice = $notice ?? '';
$email = $email ?? '';
$csrfToken = $csrfToken ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign in · GateKeeper</title>
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/public/styles.css">
</head>
<body>
<div class="auth-wrap">
  <aside class="auth-hero">
    <div class="brand"><span class="logo">🛡️</span> GateKeeper</div>
    <div>
      <h1>Right access for<br>the right people.</h1>
      <p>Sign in to see a dashboard tailored to your role and permissions.</p>
      <div class="roles-list">
        <div><b>Admin</b> · full control over users and settings</div>
        <div><b>Manager</b> · team oversight and reports</div>
        <div><b>User</b> · personal workspace</div>
      </div>
    </div>
    <small style="opacity:.6">© <?= htmlspecialchars((string) $year) ?> GateKeeper</small>
  </aside>

  <main class="auth-card-side">
    <form class="auth-card" method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/LoginController.php" novalidate>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <h2>Welcome back</h2>
      <p class="sub">Sign in to your account</p>

      <?php if ($error !== ''): ?>
        <div class="alert error show" role="alert"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($notice !== ''): ?>
        <div class="alert notice show" role="status"><?= htmlspecialchars($notice) ?></div>
      <?php endif; ?>

      <div class="field">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" value="<?= htmlspecialchars($email) ?>" autocomplete="email" placeholder="you@company.com" required>
      </div>

      <div class="field">
        <label for="password">Password</label>
        <div class="input-row">
          <input id="password" name="password" type="password" autocomplete="current-password" placeholder="••••••••" required>
        </div>
      </div>

      <div class="row-between">
        <label><input type="checkbox" name="remember" value="1"> Remember me</label>
        <a href="<?= htmlspecialchars($basePath) ?>/app/Controllers/LoginController.php">Forgot password?</a>
      </div>

      <button class="btn" type="submit">Sign in</button>
      <p class="switch">Need an account? Contact your Admin or Manager.</p>

      <div class="demo">
        <b>Demo accounts</b> (use default credentials)<br>
        Admin: <code>admin@rbac.test</code> / <code>Admin@123</code><br>
        Manager: <code>manager@rbac.test</code> / <code>Manager@123</code><br>
        User: <code>user@rbac.test</code> / <code>User@1234</code>
      </div>
    </form>
  </main>
</div>
</body>
</html>
