<?php
$year = date('Y');
$error = $error ?? '';
$fields = $fields ?? ['name' => '', 'email' => ''];
$invitation = $invitation ?? null;
$invitationToken = $invitationToken ?? '';
$csrfToken = $csrfToken ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Create account · GateKeeper</title>
  <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/public/styles.css">
</head>
<body>
<div class="auth-wrap">
  <aside class="auth-hero">
    <div class="brand"><span class="logo">🛡️</span> GateKeeper</div>
    <div>
      <h1>Create your<br>account.</h1>
      <p><?= $invitation ? 'Accept your GateKeeper invitation, then wait for an Admin or Manager to approve your account, depending on its account type.' : 'GateKeeper accounts are invitation-only. Ask an administrator to invite you.' ?></p>
    </div>
    <small style="opacity:.6">© <?= htmlspecialchars((string) $year) ?> GateKeeper</small>
  </aside>

  <main class="auth-card-side">
    <?php if ($invitation): ?>
    <form class="auth-card" method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/RegisterController.php?token=<?= rawurlencode($invitationToken) ?>" novalidate>
      <input type="hidden" name="token" value="<?= htmlspecialchars($invitationToken) ?>">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <h2>Accept invitation</h2>
      <p class="sub">Set a password for <?= htmlspecialchars($fields['email']) ?></p>

      <?php if ($error !== ''): ?>
        <div class="alert error show" role="alert"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div class="field">
        <label for="name">Full name</label>
        <input id="name" name="name" type="text" value="<?= htmlspecialchars($fields['name']) ?>" autocomplete="name" readonly>
      </div>

      <div class="field">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" value="<?= htmlspecialchars($fields['email']) ?>" autocomplete="email" readonly>
      </div>

      <div class="field">
        <label for="password">Password</label>
        <div class="input-row">
          <input id="password" name="password" type="password" autocomplete="new-password" placeholder="Uppercase, lowercase, and a number" maxlength="128" required>
        </div>
      </div>

      <div class="field">
        <label for="confirm">Confirm password</label>
        <input id="confirm" name="confirm" type="password" autocomplete="new-password" placeholder="Repeat password" required>
      </div>

      <button class="btn" type="submit">Accept invitation</button>
      <p class="switch"><a href="<?= htmlspecialchars($basePath) ?>/app/Controllers/LoginController.php">Sign in</a></p>
    </form>
    <?php else: ?>
      <div class="auth-card">
        <h2>Invitation required</h2>
        <?php if ($error !== ''): ?>
          <div class="alert error show" role="alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <p class="switch"><a href="<?= htmlspecialchars($basePath) ?>/app/Controllers/LoginController.php">Return to sign in</a></p>
      </div>
    <?php endif; ?>
  </main>
</div>
</body>
</html>
