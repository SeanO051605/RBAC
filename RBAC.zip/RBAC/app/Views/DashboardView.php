<?php
$user = $user ?? ['name' => '', 'email' => '', 'role' => 'employee'];
$view = $view ?? 'overview';
$roles = $roles ?? [];
$permissions = $permissions ?? [];
$users = $users ?? [];
$overviewCounts = $overviewCounts ?? [];
$reportSummary = $reportSummary ?? [];
$usersError = $usersError ?? '';
$accountCreated = $accountCreated ?? '';
$canManageIndividualPermissions = $canManageIndividualPermissions ?? false;
$userPermissionCatalog = $userPermissionCatalog ?? [];
$csrfToken = $csrfToken ?? '';
$availableRoles = $availableRoles ?? [];
$grantableRoles = $grantableRoles ?? [];
$managedRoles = $managedRoles ?? [];
$permissionCatalog = $permissionCatalog ?? [];
$pendingAccessRequests = $pendingAccessRequests ?? [];
$completedAccessRequests = $completedAccessRequests ?? [];
$canCreateAccessRequest = $canCreateAccessRequest ?? false;
$requestablePermissions = $requestablePermissions ?? [];
$pendingApprovals = $pendingApprovals ?? [];
$auditLogs = $auditLogs ?? [];
$teams = $teams ?? [];
$usersPagination = $usersPagination ?? [];
$teamsPagination = $teamsPagination ?? [];
$approvalsPagination = $approvalsPagination ?? [];
$pendingRequestsPagination = $pendingRequestsPagination ?? [];
$completedRequestsPagination = $completedRequestsPagination ?? [];
$auditPagination = $auditPagination ?? [];
$permissionsPagination = $permissionsPagination ?? [];
$renderPagination = static function (array $pagination, string $basePath, string $view): void {
    $totalItems = (int) ($pagination['total_items'] ?? 0);
    if ($totalItems === 0) {
        return;
    }

    $page = (int) $pagination['page'];
    $totalPages = (int) $pagination['total_pages'];
    $start = (($page - 1) * (int) $pagination['per_page']) + 1;
    $end = min($page * (int) $pagination['per_page'], $totalItems);
    echo '<p>Showing ' . $start . '-' . $end . ' of ' . $totalItems . '</p>';
    if ($totalPages < 2) {
        return;
    }

    $queryKey = (string) $pagination['query_key'];
    $query = ['view' => $view];
    foreach ($_GET as $key => $value) {
        if (
            $key !== $queryKey
            && preg_match('/^(users_page|teams_page|team_[0-9]+_members_page|invitations_page|approvals_page|requests_page|pending_requests_page|completed_requests_page|audit_page|permissions_page)$/', (string) $key)
            && is_scalar($value)
            && filter_var($value, FILTER_VALIDATE_INT) !== false
        ) {
            $query[$key] = (int) $value;
        }
    }
    $firstPage = max(1, $page - 2);
    $lastPage = min($totalPages, $page + 2);
    echo '<nav aria-label="Pagination">';
    if ($page > 1) {
        $query[$queryKey] = $page - 1;
        $url = $basePath . '/app/Controllers/DashboardController.php?' . http_build_query($query);
        echo '<a class="btn ghost sm" href="' . htmlspecialchars($url) . '">Previous</a> ';
    }
    for ($pageNumber = $firstPage; $pageNumber <= $lastPage; $pageNumber++) {
        if ($pageNumber === $page) {
            echo '<strong aria-current="page">' . $pageNumber . '</strong> ';
            continue;
        }
        $query[$queryKey] = $pageNumber;
        $url = $basePath . '/app/Controllers/DashboardController.php?' . http_build_query($query);
        echo '<a class="btn ghost sm" href="' . htmlspecialchars($url) . '">' . $pageNumber . '</a> ';
    }
    if ($page < $totalPages) {
        $query[$queryKey] = $page + 1;
        $url = $basePath . '/app/Controllers/DashboardController.php?' . http_build_query($query);
        echo '<a class="btn ghost sm" href="' . htmlspecialchars($url) . '">Next</a>';
    }
    echo '</nav>';
};
$titles = $titles ?? [
    'overview' => 'Overview',
    'profile' => 'My profile',
    'reports' => 'Reports',
    'team' => 'My team',
    'users' => 'Users & roles',
    'settings' => 'Settings',
];

function cap(string $value): string
{
    return ucfirst($value);
}

function userCan(array $user, string $permission, array $roles): bool
{
    if (isset($user['effective_permissions']) && is_array($user['effective_permissions'])) {
        $permissionMap = [
            'dashboard.view' => 'dashboard:read',
            'profile.edit' => 'profile:update',
            'reports.view' => 'reports:view',
            'team.manage' => 'teams:update',
            'teams.create' => 'teams:create',
            'teams.delete' => 'teams:delete',
            'users.view' => 'users:read',
            'users.manage' => 'users:update',
            'users.invite' => 'users:invite',
            'users.approve' => 'users:approve',
            'teams.read' => 'teams:read',
            'roles.read' => 'roles:read',
            'permissions.read' => 'permissions:read',
            'roles.create' => 'roles:create',
            'roles.update' => 'roles:update',
            'roles.delete' => 'roles:delete',
            'roles.assign' => 'roles:assign',
            'requests.read' => 'requests:read',
            'requests.create' => 'requests:create',
            'requests.approve' => 'requests:approve',
            'tasks.read' => 'tasks:read',
            'notifications.read' => 'notifications:read',
            'audit_logs.read' => 'audit_logs:read',
            'settings.read' => 'settings:read',
            'settings.manage' => 'settings:update',
        ];
        $required = $permissionMap[$permission] ?? $permission;
        return in_array($required, $user['effective_permissions'], true);
    }

    $role = $user['role'] ?? 'employee';
    return in_array($permission, $roles[$role] ?? [], true);
}

$canReviewAccessRequests = userCan($user, 'requests.approve', $roles);
$canCancelAccessRequests = userCan($user, 'requests.create', $roles);
$renderAccessRequestRows = static function (array $requests, bool $showActions) use (
    $user,
    $roles,
    $csrfToken,
    $basePath,
    $canReviewAccessRequests,
    $canCancelAccessRequests
): void {
    foreach ($requests as $request): ?>
        <tr>
            <td><?= htmlspecialchars($request['requester_name']) ?></td>
            <td><?= htmlspecialchars($request['role_name'] ?? $request['permission_key'] ?? $request['request_type']) ?></td>
            <td><?= htmlspecialchars($request['justification']) ?></td>
            <td><?= htmlspecialchars($request['status']) ?><?= $request['decision_note'] ? '<br><small>' . htmlspecialchars($request['decision_note']) . '</small>' : '' ?></td>
            <td><?= htmlspecialchars($request['created_at']) ?></td>
            <?php if ($showActions && $canReviewAccessRequests): ?>
                <td>
                    <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=requests">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                        <input type="hidden" name="action" value="access-request-decide">
                        <input type="hidden" name="view" value="requests">
                        <input type="hidden" name="request_id" value="<?= (int) $request['id'] ?>">
                        <input name="decision_note" placeholder="Decision note">
                        <label><span>Optional expiry (UTC)</span><input name="expires_at" type="datetime-local" aria-label="Optional access expiry in UTC"></label>
                        <button class="btn sm" name="decision" value="approved" type="submit">Approve</button>
                        <button class="btn sm danger" name="decision" value="rejected" type="submit">Reject</button>
                    </form>
                </td>
            <?php elseif ($showActions && $canCancelAccessRequests): ?>
                <td>
                    <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=requests">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                        <input type="hidden" name="action" value="access-request-cancel">
                        <input type="hidden" name="view" value="requests">
                        <input type="hidden" name="request_id" value="<?= (int) $request['id'] ?>">
                        <button class="btn sm danger" type="submit">Cancel request</button>
                    </form>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach;
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($titles[$view] ?? 'Dashboard') ?> · GateKeeper</title>
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/public/styles.css?v=7">
    <script>
        (() => {
            const tabKey = 'gatekeeper-tab-authenticated';
            const currentUrl = new URL(window.location.href);
            if (currentUrl.searchParams.get('tab_authenticated') === '1') {
                sessionStorage.setItem(tabKey, '1');
                currentUrl.searchParams.delete('tab_authenticated');
                window.history.replaceState({}, '', currentUrl);
            }
            if (sessionStorage.getItem(tabKey) !== '1') {
                window.location.replace(<?= json_encode($basePath . '/app/Controllers/LoginController.php') ?>);
            }
        })();
    </script>
</head>
<body>
<div class="app" id="app">
    <aside class="sidebar">
        <div class="brand"><span class="logo">🛡️</span> GateKeeper</div>

        <div class="nav-label">Workspace</div>
        <a class="nav-item <?= $view === 'overview' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=overview">🏠 Dashboard</a>
        <?php if ($user['role'] === 'manager' && userCan($user, 'teams.read', $roles)): ?>
            <a class="nav-item <?= $view === 'teams' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams">👥 My Team</a>
        <?php endif; ?>
        <?php if (userCan($user, 'requests.approve', $roles) || userCan($user, 'users.approve', $roles)): ?>
            <a class="nav-item <?= $view === 'approvals' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=approvals">✅ Approvals</a>
        <?php endif; ?>
        <?php if ($user['role'] === 'employee'): ?>
            <a class="nav-item <?= $view === 'requests' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=requests">📨 My Requests</a>
        <?php elseif (userCan($user, 'requests.read', $roles)): ?>
            <a class="nav-item <?= $view === 'requests' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=requests">📨 Access Requests</a>
        <?php endif; ?>
        <?php if (userCan($user, 'users.view', $roles) || userCan($user, 'users.invite', $roles)): ?><a class="nav-item <?= $view === 'users' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users">👤 Users</a><?php endif; ?>
        <?php if ($user['role'] !== 'manager' && userCan($user, 'teams.read', $roles)): ?><a class="nav-item <?= $view === 'teams' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams">👥 Teams</a><?php endif; ?>
        <?php if (userCan($user, 'roles.read', $roles)): ?><a class="nav-item <?= $view === 'roles' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=roles">🔐 Roles</a><?php endif; ?>
        <?php if (userCan($user, 'permissions.read', $roles)): ?><a class="nav-item <?= $view === 'permissions' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=permissions">🔑 Permissions</a><?php endif; ?>
        <?php if (userCan($user, 'reports.view', $roles)): ?><a class="nav-item <?= $view === 'reports' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=reports">📊 <?= $user['role'] === 'manager' ? 'Team Reports' : 'Reports' ?></a><?php endif; ?>
        <?php if (userCan($user, 'audit_logs.read', $roles)): ?><a class="nav-item <?= $view === 'audit-logs' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=audit-logs">📜 Audit Logs</a><?php endif; ?>
        <a class="nav-item <?= $view === 'settings' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=settings">⚙️ Settings</a>
        <?php if ($user['role'] === 'employee'): ?><a class="nav-item <?= $view === 'my-permissions' ? 'active' : '' ?>" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=my-permissions">🔎 My Permissions</a><?php endif; ?>
    </aside>

    <main class="main">
        <header class="topbar">
            <h2><?= htmlspecialchars($titles[$view] ?? 'Overview') ?></h2>
            <div class="userbox">
                <div class="who"><b><?= htmlspecialchars($user['name']) ?></b><br><span class="badge <?= htmlspecialchars($user['role']) ?>"><?= htmlspecialchars(cap($user['role'])) ?></span></div>
                <details class="user-menu">
                    <summary class="avatar" aria-label="Open account menu" title="Account menu"><?= htmlspecialchars(strtoupper(substr((string) $user['name'], 0, 2))) ?></summary>
                    <div class="panel">
                        <a class="nav-item" href="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=settings">Settings</a>
                        <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/LogoutController.php">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <button class="nav-item sign-out-button" type="submit"><span class="sign-out-label">Sign Out</span></button>
                        </form>
                    </div>
                </details>
            </div>
        </header>

        <?php if ($usersError !== ''): ?>
            <div class="alert error show" role="alert"><?= htmlspecialchars($usersError) ?></div>
        <?php endif; ?>

        <?php if ($view === 'overview'): ?>
            <section id="view-overview">
                <div class="panel welcome">
                    <h3 style="margin:0"><?= htmlspecialchars('Good ' . (date('H') < 12 ? 'morning' : (date('H') < 18 ? 'afternoon' : 'evening')) . ', ' . explode(' ', trim($user['name']))[0] . '!') ?></h3>
                    <p><?= htmlspecialchars($user['role'] === 'admin' ? 'You have full administrative access to users, roles and settings.' : ($user['role'] === 'manager' ? 'You can oversee your team, approve Employee accounts and view reports.' : 'This is your personal workspace.')) ?></p>
                </div>
                <div class="cards">
                    <?php if (userCan($user, 'users.view', $roles)): ?>
                        <div class="card"><div class="k">Total users</div><div class="v"><?= (int) ($overviewCounts['users_total'] ?? 0) ?></div><div class="d">registered accounts</div></div>
                        <div class="card"><div class="k">Active</div><div class="v"><?= (int) ($overviewCounts['users_active'] ?? 0) ?></div><div class="d">can sign in</div></div>
                        <div class="card"><div class="k">Pending approval</div><div class="v"><?= (int) ($overviewCounts['users_pending'] ?? 0) ?></div><div class="d">accounts waiting for approval</div></div>
                        <div class="card"><div class="k">Suspended / disabled</div><div class="v"><?= (int) ($overviewCounts['users_blocked'] ?? 0) ?></div><div class="d">sign-in blocked</div></div>
                    <?php endif; ?>
                    <?php if (userCan($user, 'roles.read', $roles)): ?>
                        <div class="card"><div class="k">Account types</div><div class="v">Admin / Manager / Employee</div><div class="d">organization access model</div></div>
                        <div class="card"><div class="k">Permissions</div><div class="v"><?= (int) ($overviewCounts['permissions'] ?? 0) ?></div><div class="d">available permission keys</div></div>
                    <?php endif; ?>
                    <?php if (userCan($user, 'requests.approve', $roles)): ?>
                        <div class="card"><div class="k">Pending access requests</div><div class="v"><?= (int) ($overviewCounts['pending_requests'] ?? 0) ?></div><div class="d">need review</div></div>
                    <?php endif; ?>
                    <?php if ($user['role'] === 'manager'): ?>
                        <div class="card"><div class="k">Pending account approvals</div><div class="v"><?= (int) ($overviewCounts['pending_approvals'] ?? 0) ?></div><div class="d">Employee accounts awaiting your review</div></div>
                        <div class="card"><div class="k">My teams</div><div class="v"><?= (int) ($overviewCounts['teams'] ?? 0) ?></div><div class="d">teams you are assigned to</div></div>
                    <?php endif; ?>
                    <?php if (userCan($user, 'users.manage', $roles)): ?>
                        <div class="card"><div class="k">Admins</div><div class="v"><?= (int) ($overviewCounts['admins'] ?? 0) ?></div><div class="d">privileged accounts</div></div>
                    <?php endif; ?>
                    <div class="card"><div class="k">Your role</div><div class="v"><?= htmlspecialchars(cap($user['role'])) ?></div><div class="d"><?= count($roles[$user['role']] ?? []) ?> permissions</div></div>
                    <div class="card"><div class="k">Member since</div><div class="v"><?= htmlspecialchars(date('M d, Y', strtotime($user['created_at'] ?? 'now'))) ?></div><div class="d">account created</div></div>
                </div>
                <div class="panel">
                    <h3>Your effective permissions</h3>
                    <div class="perm-grid">
                        <?php foreach ($permissions as $key => $label): ?>
                            <div class="perm <?= userCan($user, $key, $roles) ? 'on' : 'off' ?>">
                                <span><?= htmlspecialchars($label) ?></span>
                                <span><?= userCan($user, $key, $roles) ? '✓' : '✕' ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="panel">
                    <h3><?= $user['role'] === 'manager' ? 'Team activity' : ($user['role'] === 'admin' ? 'Recent changes' : 'Recent activity') ?></h3>
                    <?php if ($auditLogs !== []): ?>
                        <ul class="activity">
                            <?php foreach (array_slice($auditLogs, 0, 5) as $activity): ?>
                                <li>
                                    <span><?= htmlspecialchars($activity['action']) ?> · <?= htmlspecialchars($activity['actor_name'] ?? 'System') ?></span>
                                    <span style="color:var(--muted)"><?= htmlspecialchars($activity['created_at']) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php elseif ($user['role'] === 'admin'): ?>
                        <p>No administrative activity has been recorded yet.</p>
                    <?php else: ?>
                        <p style="color:var(--muted)">No recent activity.</p>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'reports'): ?>
            <section id="view-reports">
                <div class="panel">
                    <h3><?= $user['role'] === 'manager' ? 'Team Reports' : 'Organization Reports' ?></h3>
                    <p style="color:var(--muted)">Summary of current account, team, and access activity.</p>
                    <div class="cards">
                        <?php if (userCan($user, 'users.view', $roles)): ?>
                            <div class="card"><div class="k">Registered accounts</div><div class="v"><?= (int) ($reportSummary['users_total'] ?? 0) ?></div><div class="d"><?= (int) ($reportSummary['users_active'] ?? 0) ?> active</div></div>
                        <?php endif; ?>
                        <?php if (userCan($user, 'teams.read', $roles)): ?>
                            <div class="card"><div class="k"><?= $user['role'] === 'manager' ? 'My teams' : 'Active teams' ?></div><div class="v"><?= (int) ($reportSummary['teams'] ?? 0) ?></div><div class="d">available in your reporting scope</div></div>
                        <?php endif; ?>
                        <?php if (userCan($user, 'requests.read', $roles) || userCan($user, 'requests.approve', $roles)): ?>
                            <div class="card"><div class="k">Pending access requests</div><div class="v"><?= (int) ($reportSummary['pending_requests'] ?? 0) ?></div><div class="d">awaiting a decision</div></div>
                        <?php endif; ?>
                        <?php if (userCan($user, 'users.approve', $roles)): ?>
                            <div class="card"><div class="k">Pending account approvals</div><div class="v"><?= (int) ($reportSummary['pending_approvals'] ?? 0) ?></div><div class="d">awaiting your review</div></div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'my-permissions'): ?>
            <section id="view-my-permissions">
                <div class="panel">
                    <h3>My account types</h3>
                    <?php foreach ($user['assigned_roles'] ?? [] as $assignedRole): ?>
                        <span class="badge <?= htmlspecialchars($assignedRole['slug']) ?>"><?= htmlspecialchars($assignedRole['name']) ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="panel">
                    <h3>Effective permissions</h3>
                    <?php if (($user['effective_permissions'] ?? []) === []): ?>
                        <p>No active permissions are assigned.</p>
                    <?php else: ?>
                        <ul>
                            <?php foreach ($user['effective_permissions'] as $permissionKey): ?>
                                <li><code><?= htmlspecialchars($permissionKey) ?></code></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'teams'): ?>
            <section id="view-teams">
                <?php if (userCan($user, 'teams.create', $roles)): ?>
                    <div class="panel"><h3>Create team</h3>
                        <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams" class="user-form">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="action" value="create-team"><input type="hidden" name="view" value="teams">
                            <div class="field"><label>Name</label><input name="name" required minlength="2"></div>
                            <div class="field"><label>Description</label><input name="description" maxlength="500"></div>
                            <button class="btn sm" type="submit">Create team</button>
                        </form>
                    </div>
                <?php endif; ?>
                <?php if ($teams === []): ?><div class="panel"><h3>No teams available</h3><p>You are not a member of a team yet.</p></div><?php endif; ?>
                <?php foreach ($teams as $team): ?>
                    <div class="panel">
                        <h3><?= htmlspecialchars($team['name']) ?> <span class="badge user"><?= (int) $team['member_count'] ?> members</span></h3>
                        <p><?= htmlspecialchars($team['description']) ?></p>
                        <?php if (userCan($user, 'team.manage', $roles)): ?>
                            <details><summary class="btn ghost sm">Edit team</summary>
                                <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams" class="user-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                    <input type="hidden" name="action" value="update-team"><input type="hidden" name="view" value="teams">
                                    <input type="hidden" name="team_id" value="<?= (int) $team['id'] ?>">
                                    <div class="field"><label>Name</label><input name="name" value="<?= htmlspecialchars($team['name']) ?>" required></div>
                                    <div class="field"><label>Description</label><input name="description" value="<?= htmlspecialchars($team['description']) ?>"></div>
                                    <button class="btn sm" type="submit">Save team</button>
                                </form>
                            </details>
                        <?php endif; ?>
                        <?php if ($team['roles'] !== []): ?><p>Team roles: <?php foreach ($team['roles'] as $teamRole): ?><span class="badge manager"><?= htmlspecialchars($teamRole['name']) ?></span><?php endforeach; ?></p><?php endif; ?>
                        <div style="overflow-x:auto"><table><thead><tr><th>Member</th><th>Email</th><th>Account status</th><?php if (userCan($user, 'team.manage', $roles)): ?><th></th><?php endif; ?></tr></thead><tbody>
                            <?php foreach ($team['members'] as $member): ?><tr>
                                <td><?= htmlspecialchars($member['name']) ?></td><td><?= htmlspecialchars($member['email']) ?></td><td><?= htmlspecialchars($member['status']) ?></td>
                                <?php if (userCan($user, 'team.manage', $roles)): ?><td><form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                    <input type="hidden" name="action" value="remove-team-member"><input type="hidden" name="view" value="teams">
                                    <input type="hidden" name="team_id" value="<?= (int) $team['id'] ?>"><input type="hidden" name="member_id" value="<?= (int) $member['id'] ?>">
                                    <button class="btn ghost sm" type="submit">Remove</button>
                                </form></td><?php endif; ?>
                            </tr><?php endforeach; ?>
                        </tbody></table></div>
                        <?php $renderPagination($team['members_pagination'] ?? [], $basePath, 'teams'); ?>
                        <?php if (userCan($user, 'team.manage', $roles)): ?>
                            <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams" class="user-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="add-team-member"><input type="hidden" name="view" value="teams">
                                <input type="hidden" name="team_id" value="<?= (int) $team['id'] ?>">
                                <div class="field"><label>Add user by ID</label><input name="member_id" type="number" min="1" required></div>
                                <button class="btn ghost sm" type="submit">Add member</button>
                            </form>
                        <?php endif; ?>
                        <?php if (userCan($user, 'teams.delete', $roles)): ?>
                            <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=teams" onsubmit="return confirm('Archive this team?');">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="archive-team"><input type="hidden" name="view" value="teams">
                                <input type="hidden" name="team_id" value="<?= (int) $team['id'] ?>">
                                <button class="btn sm danger" type="submit">Archive team</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <?php $renderPagination($teamsPagination, $basePath, 'teams'); ?>
            </section>
        <?php endif; ?>

        <?php if ($view === 'users'): ?>
            <section id="view-users">
                <?php if (userCan($user, 'users.manage', $roles) || userCan($user, 'users.invite', $roles)): ?>
                    <?php if ($accountCreated !== ''): ?>
                        <div class="alert notice show" role="status">Account created for <?= htmlspecialchars($accountCreated) ?>. Provide the temporary password to the user securely; they must change it when they sign in.</div>
                    <?php endif; ?>

                    <?php if (userCan($user, 'users.invite', $roles)): ?>
                        <div class="panel">
                            <h3><?= userCan($user, 'users.manage', $roles) ? 'Create account' : 'Create User' ?></h3>
                            <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users" class="user-form account-create-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="create-user">
                                <input type="hidden" name="view" value="users">
                                <div class="field"><label for="new-user-name">Name</label><input id="new-user-name" name="name" required minlength="2"></div>
                                <div class="field"><label for="new-user-email">Email</label><input id="new-user-email" name="email" type="email" required></div>
                                <div class="field"><label for="new-user-password">Temporary password</label><input id="new-user-password" name="temporary_password" type="password" maxlength="128" autocomplete="new-password" required><small>This can be simple. The user will set a stronger password at first sign-in.</small></div>
                                <div class="field"><label for="new-user-role">Role</label>
                                    <select id="new-user-role" name="role">
                                        <?php foreach ($grantableRoles as $availableRole): ?>
                                            <?php if ($availableRole['status'] === 'active'): ?>
                                                <option value="<?= htmlspecialchars($availableRole['slug']) ?>"><?= htmlspecialchars($availableRole['name']) ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <button class="btn sm" type="submit">Create account</button>
                            </form>
                            <p>The account is active immediately. The user must change this temporary password after signing in.</p>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>

                <?php if (userCan($user, 'users.view', $roles)): ?>
                <div class="panel">
                    <h3>Users &amp; roles</h3>
                    <div style="overflow-x:auto">
                        <table class="users-table">
                            <thead><tr><th>Name</th><th>Email</th><th>Account type</th><th>Status</th><?php if (userCan($user, 'users.manage', $roles) || userCan($user, 'users.approve', $roles)): ?><th>Actions</th><?php endif; ?></tr></thead>
                            <tbody>
                                <?php foreach ($users as $person): ?>
                                    <tr>
                                        <td><b><?= htmlspecialchars($person['name']) ?></b><?= (int) $person['id'] === (int) $user['id'] ? ' <small style="color:var(--muted)">(you)</small>' : '' ?></td>
                                        <td><?= htmlspecialchars($person['email']) ?></td>
                                        <td>
                                            <?php foreach ($person['assigned_roles'] ?? [] as $assignedRole): ?>
                                                <span class="badge <?= htmlspecialchars($assignedRole['slug']) ?>"><?= htmlspecialchars($assignedRole['name']) ?></span>
                                            <?php endforeach; ?>
                                        </td>
                                        <td><span class="badge <?= ($person['status'] ?? 'invited') === 'active' ? 'user' : (($person['status'] ?? '') === 'invited' ? 'pending' : 'admin') ?>"><?= htmlspecialchars(($person['status'] ?? 'invited') === 'invited' ? 'Pending approval' : ($person['status'] ?? 'active')) ?></span></td>
                                        <?php if (userCan($user, 'users.manage', $roles) || userCan($user, 'users.approve', $roles)): ?>
                                            <td class="user-actions">
                                                <?php if (!empty($person['can_approve'])): ?>
                                                    <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users">
                                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                        <input type="hidden" name="action" value="approve-account"><input type="hidden" name="view" value="users">
                                                        <input type="hidden" name="user_id" value="<?= (int) $person['id'] ?>">
                                                        <button class="btn sm" type="submit">Approve account</button>
                                                    </form>
                                                <?php endif; ?>
                                                <?php if (userCan($user, 'users.manage', $roles) && (int) $person['id'] !== (int) $user['id']): ?>
                                                    <?php if (userCan($user, 'roles.assign', $roles)): ?>
                                                        <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users">
                                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                            <input type="hidden" name="action" value="assign-role"><input type="hidden" name="view" value="users">
                                                            <input type="hidden" name="user_id" value="<?= (int) $person['id'] ?>">
                                                            <select name="role_id" aria-label="Change account type for <?= htmlspecialchars($person['name']) ?>">
                                                                <?php foreach ($availableRoles as $availableRole): ?>
                                                                    <option value="<?= (int) $availableRole['id'] ?>" <?= ($person['role'] ?? '') === $availableRole['slug'] ? 'selected' : '' ?>><?= htmlspecialchars($availableRole['name']) ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                            <button class="btn ghost sm" type="submit">Change type</button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <?php if ($canManageIndividualPermissions): ?>
                                                        <details>
                                                            <summary class="btn ghost sm">Permissions</summary>
                                                            <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users" class="role-permission-form">
                                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                                <input type="hidden" name="action" value="update-user-permissions">
                                                                <input type="hidden" name="view" value="users">
                                                                <input type="hidden" name="user_id" value="<?= (int) $person['id'] ?>">
                                                                <p>Select the permissions this user should have. These choices override their account type and team permissions.</p>
                                                                <div class="perm-grid">
                                                                    <?php foreach ($userPermissionCatalog as $permission): ?>
                                                                        <?php $permissionIsEnabled = in_array($permission['permission_key'], $person['effective_permissions'] ?? [], true); ?>
                                                                        <label class="perm <?= $permissionIsEnabled ? 'on' : 'off' ?>">
                                                                            <input type="checkbox" name="permission_ids[]" value="<?= (int) $permission['id'] ?>" <?= $permissionIsEnabled ? 'checked' : '' ?>>
                                                                            <span><code><?= htmlspecialchars($permission['permission_key']) ?></code><br><small><?= htmlspecialchars($permission['description']) ?></small></span>
                                                                        </label>
                                                                    <?php endforeach; ?>
                                                                </div>
                                                                <button class="btn sm" type="submit">Save permissions</button>
                                                            </form>
                                                        </details>
                                                    <?php endif; ?>
                                                    <details>
                                                        <summary class="btn ghost sm">Edit</summary>
                                                        <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users" class="user-edit-form">
                                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                            <input type="hidden" name="action" value="update-user">
                                                            <input type="hidden" name="view" value="users">
                                                            <input type="hidden" name="user_id" value="<?= (int) $person['id'] ?>">
                                                            <div class="field"><label>Name</label><input name="name" value="<?= htmlspecialchars($person['name']) ?>" required minlength="2"></div>
                                                            <div class="field"><label>Email</label><input name="email" type="email" value="<?= htmlspecialchars($person['email']) ?>" required></div>
                                                            <div class="field"><label>New password <small>(leave blank to keep current)</small></label><input name="password" type="password" maxlength="128" autocomplete="new-password"></div>
                                                            <div class="field"><label>Status</label>
                                                                <select name="status">
                                                                    <?php if (($person['status'] ?? '') === 'invited'): ?><option value="invited" selected>Pending approval</option><?php endif; ?>
                                                                    <?php if (($person['status'] ?? '') === 'active'): ?><option value="active" selected>Active / approved</option><?php endif; ?>
                                                                    <option value="suspended" <?= ($person['status'] ?? '') === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                                                                    <option value="disabled" <?= ($person['status'] ?? '') === 'disabled' ? 'selected' : '' ?>>Disabled</option>
                                                                </select>
                                                            </div>
                                                            <button class="btn sm" type="submit">Save changes</button>
                                                        </form>
                                                    </details>
                                                    <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=users" onsubmit="return confirm('Remove this user? This cannot be undone.');">
                                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                        <input type="hidden" name="action" value="delete-user">
                                                        <input type="hidden" name="view" value="users">
                                                        <input type="hidden" name="user_id" value="<?= (int) $person['id'] ?>">
                                                        <button class="btn sm danger" type="submit">Remove</button>
                                                    </form>
                                                <?php elseif (userCan($user, 'users.manage', $roles) && (int) $person['id'] === (int) $user['id']): ?>
                                                    <span>Use My profile to edit your account</span>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php $renderPagination($usersPagination, $basePath, 'users'); ?>
                </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if ($view === 'roles'): ?>
            <section id="view-roles">
                <div class="panel"><h3>Fixed account types</h3>
                    <p>GateKeeper accounts use one of three fixed types. Custom types are disabled; use this view to inspect account type membership.</p>
                </div>
                <?php foreach ($managedRoles as $managedRole): ?>
                    <div class="panel">
                        <h3><?= htmlspecialchars($managedRole['name']) ?>
                            <span class="badge <?= htmlspecialchars($managedRole['slug']) ?>"><?= (int) $managedRole['member_count'] ?> accounts</span>
                        </h3>
                        <p><?= htmlspecialchars($managedRole['description']) ?></p>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <?php if ($view === 'permissions'): ?>
            <section id="view-permissions">
                <div class="panel">
                    <h3>Account type permission matrix</h3>
                    <div style="overflow-x:auto">
                        <table><thead><tr><th>Permission</th><?php foreach ($managedRoles as $managedRole): ?><th><?= htmlspecialchars($managedRole['name']) ?></th><?php endforeach; ?></tr></thead><tbody>
                            <?php foreach ($permissionCatalog as $permission): ?>
                                <tr>
                                    <td><code><?= htmlspecialchars($permission['permission_key']) ?></code></td>
                                    <?php foreach ($managedRoles as $managedRole): ?>
                                        <td><?= in_array((int) $permission['id'], array_map('intval', $managedRole['permission_ids']), true) ? 'Yes' : '—' ?></td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody></table>
                    </div>
                    <?php $renderPagination($permissionsPagination, $basePath, 'permissions'); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'approvals'): ?>
            <section id="view-approvals">
                <div class="panel">
                    <h3>Pending account approvals</h3>
                    <?php if ($pendingApprovals === []): ?>
                        <p>No accounts are waiting for approval.</p>
                    <?php else: ?>
                        <div style="overflow-x:auto"><table>
                            <thead><tr><th>Name</th><th>Email</th><th>Account type</th><th>Registered</th><th>Action</th></tr></thead>
                            <tbody><?php foreach ($pendingApprovals as $pendingApproval): ?>
                                <tr>
                                    <td><?= htmlspecialchars($pendingApproval['name']) ?></td>
                                    <td><?= htmlspecialchars($pendingApproval['email']) ?></td>
                                    <td><?= htmlspecialchars(cap($pendingApproval['role'])) ?></td>
                                    <td><?= htmlspecialchars($pendingApproval['created_at']) ?></td>
                                    <td>
                                        <?php if (!empty($pendingApproval['can_approve'])): ?>
                                            <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=approvals">
                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                <input type="hidden" name="action" value="approve-account">
                                                <input type="hidden" name="view" value="approvals">
                                                <input type="hidden" name="user_id" value="<?= (int) $pendingApproval['id'] ?>">
                                                <button class="btn sm" type="submit">Approve account</button>
                                            </form>
                                        <?php else: ?>Approval is not available<?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?></tbody>
                        </table></div>
                    <?php endif; ?>
                    <?php $renderPagination($approvalsPagination, $basePath, 'approvals'); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'requests' || $view === 'approvals'): ?>
            <section id="view-requests">
                <?php if ($view === 'requests' && $canCreateAccessRequest): ?>
                    <div class="panel">
                        <h3>Request a permission</h3>
                        <p>Choose the access you need and explain why. An administrator or manager will review your request.</p>
                        <?php if ($requestablePermissions === []): ?>
                            <p>You already have all available permissions or have pending requests for the remaining permissions.</p>
                        <?php else: ?>
                            <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=requests" class="user-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="access-request-create">
                                <input type="hidden" name="view" value="requests">
                                <div class="field">
                                    <label for="request-permission">Permission</label>
                                    <select id="request-permission" name="permission_id" required>
                                        <option value="">Choose a permission</option>
                                        <?php foreach ($requestablePermissions as $permission): ?>
                                            <option value="<?= (int) $permission['id'] ?>"><?= htmlspecialchars($permission['description'] ?: $permission['permission_key']) ?> (<?= htmlspecialchars($permission['category']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <label for="request-justification">Why do you need this permission?</label>
                                    <textarea id="request-justification" name="justification" required minlength="10" maxlength="2000"></textarea>
                                </div>
                                <button class="btn sm" type="submit">Submit request</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php $requestHeading = $canReviewAccessRequests
                    ? ($user['role'] === 'manager' ? 'Team access requests' : 'Organization access requests')
                    : 'My access requests'; ?>
                <div class="panel">
                    <h3>Pending <?= htmlspecialchars($requestHeading) ?></h3>
                    <?php if ($pendingAccessRequests === []): ?><p>No pending access requests.</p><?php else: ?>
                        <div style="overflow-x:auto"><table>
                            <thead><tr><th>Requester</th><th>Requested access</th><th>Justification</th><th>Status</th><th>Created</th><?php if ($canReviewAccessRequests || $canCancelAccessRequests): ?><th><?= $canReviewAccessRequests ? 'Decision' : 'Action' ?></th><?php endif; ?></tr></thead>
                            <tbody><?php $renderAccessRequestRows($pendingAccessRequests, true); ?></tbody>
                        </table></div>
                    <?php endif; ?>
                    <?php $renderPagination($pendingRequestsPagination, $basePath, $view); ?>
                </div>
                <div class="panel">
                    <h3>Request history</h3>
                    <?php if ($completedAccessRequests === []): ?><p>No completed access requests yet.</p><?php else: ?>
                        <div style="overflow-x:auto"><table>
                            <thead><tr><th>Requester</th><th>Requested access</th><th>Justification</th><th>Status</th><th>Created</th></tr></thead>
                            <tbody><?php $renderAccessRequestRows($completedAccessRequests, false); ?></tbody>
                        </table></div>
                    <?php endif; ?>
                    <?php $renderPagination($completedRequestsPagination, $basePath, $view); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'audit-logs'): ?>
            <section id="view-audit-logs">
                <div class="panel"><h3>Audit history</h3>
                    <?php if ($auditLogs === []): ?><p>No audit events recorded yet.</p><?php else: ?>
                        <div style="overflow-x:auto"><table>
                            <thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>Result</th><th>Details</th></tr></thead>
                            <tbody><?php foreach ($auditLogs as $log): ?>
                                <tr>
                                    <td><?= htmlspecialchars($log['created_at']) ?></td>
                                    <td><?= htmlspecialchars($log['actor_name'] ?? 'System') ?></td>
                                    <td><?= htmlspecialchars($log['action']) ?></td>
                                    <td><?= htmlspecialchars($log['target_type'] . ' ' . ($log['target_id'] ?? '')) ?></td>
                                    <td><?= htmlspecialchars($log['result']) ?></td>
                                    <td><details><summary>View</summary><pre><?= htmlspecialchars(json_encode(['before' => json_decode($log['before_data'] ?? 'null', true), 'after' => json_decode($log['after_data'] ?? 'null', true)], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) ?: '') ?></pre></details></td>
                                </tr>
                            <?php endforeach; ?></tbody>
                        </table></div>
                    <?php endif; ?>
                    <?php $renderPagination($auditPagination, $basePath, 'audit-logs'); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($view === 'settings'): ?>
            <section id="view-settings">
                <div class="panel" style="max-width:520px;">
                    <h3>Profile details</h3>
                    <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=settings">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                        <input type="hidden" name="action" value="profile-update">
                        <input type="hidden" name="view" value="settings">
                        <div class="field"><label>Full name</label><input name="name" value="<?= htmlspecialchars($user['name']) ?>" required></div>
                        <div class="field"><label>Email</label><input value="<?= htmlspecialchars($user['email']) ?>" disabled></div>
                        <div class="field"><label>Role</label><input value="<?= htmlspecialchars(cap($user['role'])) ?>" disabled></div>
                        <button class="btn sm" type="submit">Save changes</button>
                    </form>
                </div>
                <?php if (userCan($user, 'settings.manage', $roles)): ?>
                    <div class="panel"><h3>System settings</h3>
                        <p>Restore the example users, teams, pending approvals, access request, invitation, and starter audit events. This replaces the current users and teams.</p>
                        <form method="post" action="<?= htmlspecialchars($basePath) ?>/app/Controllers/DashboardController.php?view=settings" style="margin-top:12px;" onsubmit="return confirm('Replace the current users and teams with the demo data?');">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="action" value="reset-demo">
                            <input type="hidden" name="view" value="settings">
                            <button class="btn sm danger" type="submit">Reset demo data</button>
                        </form>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if ($view === 'forbidden'): ?>
            <section class="panel"><h3>Access denied</h3><p>You do not have permission to view this page.</p></section>
        <?php endif; ?>
    </main>
</div>
<script>
    (() => {
        const loginUrl = <?= json_encode($basePath . '/app/Controllers/LoginController.php') ?>;
        const channel = 'BroadcastChannel' in window
            ? new BroadcastChannel('gatekeeper-session')
            : null;

        const notifyLogout = () => {
            if (channel) {
                channel.postMessage('logout');
            }
            try {
                localStorage.setItem('gatekeeper-session-logout', String(Date.now()));
            } catch (error) {
                // Storage may be unavailable; the close beacon still attempts logout.
            }
        };

        const redirectToLogin = () => {
            sessionStorage.removeItem('gatekeeper-tab-authenticated');
            window.location.replace(loginUrl);
        };

        if (channel) {
            channel.addEventListener('message', (event) => {
                if (event.data === 'logout') {
                    redirectToLogin();
                }
            });
        }
        window.addEventListener('storage', (event) => {
            if (event.key === 'gatekeeper-session-logout') {
                redirectToLogin();
            }
        });
        document.querySelector('.user-menu form[action*="LogoutController.php"]')
            ?.addEventListener('submit', () => {
                notifyLogout();
                sessionStorage.removeItem('gatekeeper-tab-authenticated');
            });

        document.addEventListener('click', (event) => {
            const link = event.target instanceof Element
                ? event.target.closest('a[href]')
                : null;
            const opensSeparateTab = event.metaKey
                || event.ctrlKey
                || event.shiftKey
                || (link && link.target === '_blank');
            if (link && link.origin === window.location.origin && opensSeparateTab) {
                event.preventDefault();
                window.open(loginUrl, '_blank', 'noopener');
            }
        }, true);
    })();
</script>
</body>
</html>
