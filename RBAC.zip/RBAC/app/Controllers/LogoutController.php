<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\SecurityModel;

class LogoutController
{
    public function index(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !SecurityModel::verifyCsrf($_POST['csrf_token'] ?? null)) {
            http_response_code(400);
            echo 'Invalid logout request.';
            return;
        }

        $user = $_SESSION['user'] ?? null;
        if ($user) {
            (new AuditLogModel())->record((int) $user['id'], 'logout', 'user', (string) $user['id']);
        }

        $_SESSION = [];
        session_regenerate_id(true);

        if (($_GET['close'] ?? '') === '1') {
            http_response_code(204);
            return;
        }

        $basePath = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        header('Location: ' . $basePath . '/app/Controllers/LoginController.php');
        exit;
    }
}
