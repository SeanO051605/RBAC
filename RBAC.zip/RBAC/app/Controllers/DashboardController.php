<?php

namespace App\Controllers;

use App\Models\DashboardModel;
use App\Models\AuditLogModel;
use App\Models\AccessRequestModel;
use App\Models\InvitationModel;
use App\Models\SecurityModel;
use App\Models\TeamModel;

class DashboardController
{
    private DashboardModel $dashboardModel;
    private InvitationModel $invitations;
    private AuditLogModel $audit;
    private AccessRequestModel $accessRequests;
    private TeamModel $teams;

    private function render(string $viewName, array $data = []): void
    {
        $data['basePath'] = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        $data['csrfToken'] = SecurityModel::csrfToken();
        extract($data, EXTR_SKIP);
        $file = dirname(__DIR__) . '/Views/' . basename($viewName) . '.php';

        if (!is_file($file)) {
            throw new \RuntimeException('View not found: ' . $viewName);
        }

        require $file;
    }

    private function redirect(string $path): void
    {
        $basePath = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        header('Location: ' . $basePath . $path);
        exit;
    }

    private function requireLogin(): array
    {
        $user = $_SESSION['user'] ?? null;
        if (!$user) {
            $this->redirect('/login');
        }

        $currentUser = $this->dashboardModel->findUser((int) $user['id']);
        if (!$currentUser || ($currentUser['status'] ?? '') !== 'active') {
            unset($_SESSION['user']);
            $this->redirect('/login');
        }

        if (!empty($currentUser['must_change_password'])) {
            $this->redirect('/change-password');
        }

        $_SESSION['user'] = $currentUser;

        return $currentUser;
    }

    private function setUsersError(string $message): void
    {
        $_SESSION['users_error'] = $message;
    }

    private function paginateRows(array $rows, string $queryKey, int $perPage = 10): array
    {
        $requestedPage = $_GET[$queryKey] ?? 1;
        $page = is_scalar($requestedPage) ? filter_var($requestedPage, FILTER_VALIDATE_INT) : false;
        $page = $page === false ? 1 : max(1, $page);
        $totalItems = count($rows);
        $totalPages = max(1, (int) ceil($totalItems / $perPage));
        $page = min($page, $totalPages);

        return [
            'items' => array_slice($rows, ($page - 1) * $perPage, $perPage),
            'pagination' => [
                'page' => $page,
                'total_pages' => $totalPages,
                'total_items' => $totalItems,
                'per_page' => $perPage,
                'query_key' => $queryKey,
            ],
        ];
    }

    private function isLastActivePrivilegedUser(int $userId, string $currentStatus, string $nextStatus): bool
    {
        if ($currentStatus !== 'active' || $nextStatus === 'active') {
            return false;
        }

        return $this->dashboardModel->hasRole($userId, 'admin')
            && $this->dashboardModel->countActiveAdmins() <= 1;
    }

    public function __construct()
    {
        $this->dashboardModel = new DashboardModel();
        $this->invitations = new InvitationModel();
        $this->audit = new AuditLogModel();
        $this->accessRequests = new AccessRequestModel();
        $this->teams = new TeamModel();
    }

    public function index(): void
    {
        $user = $this->requireLogin();
        $user['effective_permissions'] = $this->dashboardModel->permissionsForUser((int) $user['id']);
        $user['assigned_roles'] = $this->dashboardModel->rolesForUser((int) $user['id']);
        $_SESSION['user'] = $user;
        if (!$this->dashboardModel->can($user, 'dashboard.view', [])) {
            http_response_code(403);
            echo 'You do not have permission to access the dashboard.';
            return;
        }
        $config = require dirname(__DIR__, 2) . '/config/app.php';
        $canCreateAccessRequest = !$this->dashboardModel->hasRole((int) $user['id'], 'admin')
            && $this->dashboardModel->can($user, 'requests.create', $config['roles']);
        $canReadUsers = $this->dashboardModel->can($user, 'users.view', $config['roles']);
        $canInviteUsers = $this->dashboardModel->can($user, 'users.invite', $config['roles']);
        $view = $_GET['view'] ?? 'overview';
        $viewPermissions = [
            'roles' => 'roles.read',
            'permissions' => 'permissions.read',
            'teams' => 'teams.read',
            'audit-logs' => 'audit_logs.read',
            'reports' => 'reports.view',
        ];
        $allowedViews = [
            'overview', 'users', 'roles', 'permissions', 'teams', 'requests',
            'approvals', 'audit-logs', 'reports', 'settings', 'my-permissions', 'forbidden',
        ];
        if (!in_array($view, $allowedViews, true)) {
            http_response_code(404);
            echo 'Page not found';
            return;
        }
        $canReviewRequests = $this->dashboardModel->can($user, 'requests.approve', $config['roles']);
        $canApproveAccounts = $this->dashboardModel->can($user, 'users.approve', $config['roles']);
        if (
            ($view === 'users' && !$canReadUsers && !$canInviteUsers)
            || (isset($viewPermissions[$view]) && !$this->dashboardModel->can($user, $viewPermissions[$view], $config['roles']))
            || ($view === 'approvals' && !$canReviewRequests && !$canApproveAccounts)
            || ($view === 'my-permissions' && ($user['role'] ?? '') !== 'employee')
        ) {
            http_response_code(403);
            $view = 'forbidden';
        }
        $usersError = $_SESSION['users_error'] ?? '';
        unset($_SESSION['users_error']);
        $accountCreated = $_SESSION['account_created'] ?? '';
        unset($_SESSION['account_created']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!SecurityModel::verifyCsrf($_POST['csrf_token'] ?? null)) {
                http_response_code(400);
                $this->setUsersError('Your form session expired. Reload the page and try again.');
                $this->redirect('/app/Controllers/DashboardController.php?view=' . urlencode((string) ($_POST['view'] ?? 'overview')));
            }

            $action = $_POST['action'] ?? '';
            $canManageUsers = $this->dashboardModel->can($user, 'users.manage', $config['roles']);

            if ($action === 'profile-update') {
                $name = trim((string) ($_POST['name'] ?? ''));
                if (!$this->dashboardModel->can($user, 'profile.edit', $config['roles'])) {
                    $this->setUsersError('You are not allowed to edit this profile.');
                } elseif (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
                    $this->setUsersError('Name must contain between 2 and 120 characters.');
                } else {
                    $before = ['name' => $user['name']];
                    $this->dashboardModel->updateProfile((int) $user['id'], $name);
                    $user['name'] = $name;
                    $_SESSION['user'] = $user;
                    $this->audit->record((int) $user['id'], 'user.profile_updated', 'user', (string) $user['id'], $before, ['name' => $name]);
                }
            }

            if ($action === 'create-user') {
                $nameValue = $_POST['name'] ?? null;
                $emailValue = $_POST['email'] ?? null;
                $password = $_POST['temporary_password'] ?? null;
                $roleValue = $_POST['role'] ?? null;
                $name = is_string($nameValue) ? trim($nameValue) : '';
                $email = is_string($emailValue) ? strtolower(trim($emailValue)) : '';
                $roleSlug = is_string($roleValue) ? $roleValue : '';
                $role = $this->dashboardModel->findRoleBySlug($roleSlug);

                if (!$canInviteUsers) {
                    $this->setUsersError('You are not allowed to create accounts.');
                } elseif (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
                    $this->setUsersError('Name must contain between 2 and 120 characters.');
                } elseif (mb_strlen($email) > 254) {
                    $this->setUsersError('Email address must be 254 characters or fewer.');
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $this->setUsersError('Enter a valid email address.');
                } elseif ($this->dashboardModel->emailExists($email)) {
                    $this->setUsersError('An account already uses this email.');
                } elseif (!is_string($password)) {
                    $this->setUsersError('Enter a valid temporary password.');
                } elseif ($password === '' || mb_strlen($password) > 128) {
                    $this->setUsersError('Temporary password is required and must be 128 characters or fewer.');
                } elseif (!$role || !$this->dashboardModel->canGrantRole($user, (int) $role['id'])) {
                    $this->setUsersError('Choose an active role.');
                } else {
                    $createdUser = $this->dashboardModel->createUser(
                        $name,
                        $email,
                        $password,
                        $role['slug'],
                        'active',
                        true
                    );
                    $_SESSION['account_created'] = $email;
                    $this->audit->record((int) $user['id'], 'user.created', 'user', (string) $createdUser['id'], null, [
                        'email' => $email,
                        'role' => $role['slug'],
                    ]);
                }

                $this->redirect('/app/Controllers/DashboardController.php?view=users');
            }

            if ($action === 'cancel-invitation') {
                $invitationId = (int) ($_POST['invitation_id'] ?? 0);
                if ($this->dashboardModel->can($user, 'users.update', $config['roles'])) {
                    $this->invitations->cancel($invitationId);
                    $this->audit->record((int) $user['id'], 'invitation.cancelled', 'invitation', (string) $invitationId);
                } else {
                    $this->setUsersError('You are not allowed to cancel invitations.');
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=users');
            }

            if ($action === 'create-role') {
                $this->setUsersError('GateKeeper account types are fixed: Admin, Manager, and Employee.');
                $this->redirect('/app/Controllers/DashboardController.php?view=roles');
            }

            if ($action === 'update-role') {
                $this->setUsersError('GateKeeper account type permissions are managed by the system.');
                $this->redirect('/app/Controllers/DashboardController.php?view=roles');
            }

            if ($action === 'delete-role') {
                $this->setUsersError('GateKeeper account types cannot be deleted.');
                $this->redirect('/app/Controllers/DashboardController.php?view=roles');
            }

            if ($action === 'assign-role' || $action === 'revoke-role') {
                $targetUserId = (int) ($_POST['user_id'] ?? 0);
                $roleId = (int) ($_POST['role_id'] ?? 0);
                if ($action === 'revoke-role') {
                    $this->setUsersError('Every account must have one type: Admin, Manager, or Employee.');
                } elseif (!$this->dashboardModel->can($user, 'roles.assign', $config['roles'])) {
                    $this->setUsersError('You are not allowed to assign roles.');
                } elseif ($targetUserId === (int) $user['id']) {
                    $this->setUsersError('You cannot change your own account type.');
                } else {
                    $role = $this->dashboardModel->findRoleById($roleId);
                    $target = $this->dashboardModel->findUser($targetUserId);
                    if (
                        !$role
                        || $role['status'] !== 'active'
                        || !in_array($role['slug'], ['admin', 'manager', 'employee'], true)
                    ) {
                        $this->setUsersError('Choose an active role.');
                    } elseif (!$target) {
                        $this->setUsersError('The selected account does not exist.');
                    } elseif (
                        ($target['status'] ?? '') === 'active'
                        && $this->dashboardModel->hasRole($targetUserId, 'admin')
                        && $role['slug'] !== 'admin'
                        && $this->dashboardModel->countActiveAdmins() <= 1
                    ) {
                        $this->setUsersError('You cannot change the last active administrator to another account type.');
                    } elseif (
                        !$this->dashboardModel->canGrantRole($user, $roleId)
                    ) {
                        $this->setUsersError('You are not allowed to grant this role.');
                    } else {
                        $beforeRoles = array_column($this->dashboardModel->rolesForUser($targetUserId), 'slug');
                        $this->dashboardModel->assignUserRole($targetUserId, $roleId, (int) $user['id']);
                        $this->audit->record(
                            (int) $user['id'],
                            'user.account_type_changed',
                            'user',
                            (string) $targetUserId,
                            ['roles' => $beforeRoles],
                            ['role' => $role['slug']]
                        );
                    }
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=users');
            }

            if ($action === 'update-user-permissions') {
                $targetUserId = (int) ($_POST['user_id'] ?? 0);
                $submittedPermissionIds = $_POST['permission_ids'] ?? [];
                if (
                    !$this->dashboardModel->hasRole((int) $user['id'], 'admin')
                    || !$this->dashboardModel->can($user, 'users.manage', $config['roles'])
                ) {
                    $this->setUsersError('Only administrators can change user permissions.');
                } elseif ($targetUserId === (int) $user['id']) {
                    $this->setUsersError('You cannot change your own permissions.');
                } elseif (!$this->dashboardModel->findUser($targetUserId)) {
                    $this->setUsersError('The selected account does not exist.');
                } elseif (!is_array($submittedPermissionIds)) {
                    $this->setUsersError('The submitted permissions are invalid.');
                } else {
                    $permissionIds = [];
                    $validPermissionIds = true;
                    foreach ($submittedPermissionIds as $submittedPermissionId) {
                        if (!is_string($submittedPermissionId) && !is_int($submittedPermissionId)) {
                            $this->setUsersError('The submitted permissions are invalid.');
                            $validPermissionIds = false;
                            break;
                        }
                        $permissionId = filter_var($submittedPermissionId, FILTER_VALIDATE_INT);
                        if ($permissionId === false || $permissionId < 1) {
                            $this->setUsersError('The submitted permissions are invalid.');
                            $validPermissionIds = false;
                            break;
                        }
                        $permissionIds[] = $permissionId;
                    }

                    if ($validPermissionIds) {
                        try {
                            $beforePermissions = $this->dashboardModel->permissionsForUser($targetUserId);
                            $this->dashboardModel->setUserPermissions(
                                $targetUserId,
                                $permissionIds,
                                (int) $user['id']
                            );
                            $afterPermissions = $this->dashboardModel->permissionsForUser($targetUserId);
                            sort($beforePermissions);
                            sort($afterPermissions);
                            $this->audit->record(
                                (int) $user['id'],
                                'user.permissions_changed',
                                'user',
                                (string) $targetUserId,
                                ['permissions' => $beforePermissions],
                                ['permissions' => $afterPermissions]
                            );
                        } catch (\InvalidArgumentException $exception) {
                            $this->setUsersError($exception->getMessage());
                        }
                    }
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=users');
            }

            if ($action === 'access-request-create') {
                $permissionIdValue = $_POST['permission_id'] ?? null;
                $permissionId = is_scalar($permissionIdValue)
                    ? filter_var($permissionIdValue, FILTER_VALIDATE_INT)
                    : false;
                $justification = trim((string) ($_POST['justification'] ?? ''));
                if (!$canCreateAccessRequest) {
                    $this->setUsersError('You are not allowed to submit access requests.');
                } elseif ($permissionId === false || $permissionId < 1) {
                    $this->setUsersError('Choose a permission to request.');
                } elseif (mb_strlen($justification) < 10 || mb_strlen($justification) > 2000) {
                    $this->setUsersError('Explain why you need this permission in 10 to 2000 characters.');
                } else {
                    try {
                        $requestedPermission = null;
                        foreach ($this->dashboardModel->allPermissions() as $permission) {
                            if ((int) $permission['id'] === $permissionId) {
                                $requestedPermission = $permission;
                                break;
                            }
                        }
                        if (!$requestedPermission) {
                            throw new \InvalidArgumentException('Choose a valid permission to request.');
                        }
                        if (in_array($requestedPermission['permission_key'], $user['effective_permissions'], true)) {
                            throw new \InvalidArgumentException('You already have this permission.');
                        }
                        $requestId = $this->accessRequests->createPermissionRequest(
                            (int) $user['id'],
                            $permissionId,
                            $justification
                        );
                        $this->audit->record(
                            (int) $user['id'],
                            'access_request.created',
                            'access_request',
                            (string) $requestId,
                            null,
                            ['permission' => $requestedPermission['permission_key']]
                        );
                    } catch (\InvalidArgumentException $exception) {
                        $this->setUsersError($exception->getMessage());
                    }
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=requests');
            }

            if ($action === 'access-request-decide') {
                $requestId = (int) ($_POST['request_id'] ?? 0);
                $decision = (string) ($_POST['decision'] ?? '');
                $note = trim((string) ($_POST['decision_note'] ?? ''));
                $expiresAt = trim((string) ($_POST['expires_at'] ?? ''));
                if (!$this->dashboardModel->can($user, 'requests.approve', $config['roles'])) {
                    $this->setUsersError('You are not allowed to decide access requests.');
                } elseif (!in_array($decision, ['approved', 'rejected'], true)) {
                    $this->setUsersError('Choose approve or reject.');
                } else {
                    try {
                        $requestScope = $this->dashboardModel->hasRole((int) $user['id'], 'admin')
                            ? 'all'
                            : ($this->dashboardModel->hasRole((int) $user['id'], 'manager') ? 'team' : 'own');
                        $decided = $this->accessRequests->decide(
                            $requestId,
                            (int) $user['id'],
                            $decision,
                            $note,
                            $expiresAt !== '' ? $expiresAt : null,
                            $requestScope
                        );
                        if ($decided) {
                            $this->audit->record((int) $user['id'], 'access_request.' . $decision, 'access_request', (string) $requestId, null, ['note' => $note]);
                        } else {
                            $this->setUsersError('This request has already been decided or does not exist.');
                        }
                    } catch (\InvalidArgumentException $exception) {
                        $this->setUsersError($exception->getMessage());
                    }
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=approvals');
            }

            if ($action === 'access-request-cancel') {
                $requestId = (int) ($_POST['request_id'] ?? 0);
                if ($this->accessRequests->cancel($requestId, (int) $user['id'])) {
                    $this->audit->record((int) $user['id'], 'access_request.cancelled', 'access_request', (string) $requestId);
                } else {
                    $this->setUsersError('This request is no longer pending or cannot be cancelled.');
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=requests');
            }

            if (in_array($action, ['create-team', 'update-team', 'archive-team', 'add-team-member', 'remove-team-member', 'assign-team-role', 'revoke-team-role'], true)) {
                $teamId = (int) ($_POST['team_id'] ?? 0);
                $teamName = trim((string) ($_POST['name'] ?? ''));
                $teamDescription = trim((string) ($_POST['description'] ?? ''));
                $teamMemberId = (int) ($_POST['member_id'] ?? 0);
                $teamRoleId = (int) ($_POST['role_id'] ?? 0);
                $isOrgAdmin = $this->dashboardModel->can($user, 'settings.manage', $config['roles']);
                $accessibleTeams = $this->teams->allForUser((int) $user['id'], $isOrgAdmin);
                $canManageTeam = $isOrgAdmin || in_array($teamId, array_map('intval', array_column($accessibleTeams, 'id')), true);

                if ($action === 'create-team') {
                    if (!$this->dashboardModel->can($user, 'teams.create', $config['roles'])) {
                        $this->setUsersError('You are not allowed to create teams.');
                    } elseif (mb_strlen($teamName) < 2 || mb_strlen($teamName) > 120) {
                        $this->setUsersError('Team name must contain between 2 and 120 characters.');
                    } elseif (mb_strlen($teamDescription) > 500) {
                        $this->setUsersError('Team description must be 500 characters or fewer.');
                    } else {
                        $newTeamId = $this->teams->create($teamName, $teamDescription);
                        $this->audit->record((int) $user['id'], 'team.created', 'team', (string) $newTeamId, null, ['name' => $teamName]);
                    }
                    $this->redirect('/app/Controllers/DashboardController.php?view=teams');
                }

                if (!$canManageTeam || !$this->dashboardModel->can($user, 'team.manage', $config['roles'])) {
                    $this->setUsersError('You are not allowed to manage this team.');
                } elseif ($action === 'update-team') {
                    if (mb_strlen($teamName) < 2 || mb_strlen($teamName) > 120) {
                        $this->setUsersError('Team name must contain between 2 and 120 characters.');
                    } elseif (mb_strlen($teamDescription) > 500) {
                        $this->setUsersError('Team description must be 500 characters or fewer.');
                    } else {
                        $this->teams->update($teamId, $teamName, $teamDescription);
                        $this->audit->record((int) $user['id'], 'team.updated', 'team', (string) $teamId, null, ['name' => $teamName, 'description' => $teamDescription]);
                    }
                } elseif ($action === 'archive-team') {
                    if (!$this->dashboardModel->can($user, 'teams.delete', $config['roles'])) {
                        $this->setUsersError('You are not allowed to archive teams.');
                    } else {
                        $this->teams->archive($teamId);
                        $this->audit->record((int) $user['id'], 'team.archived', 'team', (string) $teamId);
                    }
                } elseif ($action === 'add-team-member') {
                    $this->teams->addMember($teamId, $teamMemberId, (int) $user['id']);
                    $this->audit->record((int) $user['id'], 'team.member_added', 'team', (string) $teamId, null, ['user_id' => $teamMemberId]);
                } elseif ($action === 'remove-team-member') {
                    $this->teams->removeMember($teamId, $teamMemberId);
                    $this->audit->record((int) $user['id'], 'team.member_removed', 'team', (string) $teamId, ['user_id' => $teamMemberId]);
                } elseif ($action === 'assign-team-role' || $action === 'revoke-team-role') {
                    if (!$this->dashboardModel->can($user, 'roles.assign', $config['roles'])) {
                        $this->setUsersError('You are not allowed to assign team roles.');
                    } elseif (
                        ($teamRole = $this->dashboardModel->findRoleById($teamRoleId)) === null
                        || !in_array($teamRole['slug'], ['admin', 'manager', 'employee'], true)
                    ) {
                        $this->setUsersError('Only Admin, Manager, or Employee can be assigned to teams.');
                    } elseif ($action === 'assign-team-role') {
                        $this->teams->assignRole($teamId, $teamRoleId, (int) $user['id']);
                    } else {
                        $this->teams->revokeRole($teamId, $teamRoleId);
                    }
                }
                $this->redirect('/app/Controllers/DashboardController.php?view=teams');
            }
            if ($action === 'update-user') {
                $id = (int) ($_POST['user_id'] ?? 0);
                $current = $this->dashboardModel->findUser($id);
                $name = trim((string) ($_POST['name'] ?? ''));
                $email = strtolower(trim((string) ($_POST['email'] ?? '')));
                $password = (string) ($_POST['password'] ?? '');
                $status = (string) ($_POST['status'] ?? 'active');

                if (!$canManageUsers) {
                    $this->setUsersError('You are not allowed to manage users.');
                } elseif (!$current || $id === (int) $user['id']) {
                    $this->setUsersError('You cannot edit this account from user management.');
                } elseif (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
                    $this->setUsersError('Name must contain between 2 and 120 characters.');
                } elseif (mb_strlen($email) > 254) {
                    $this->setUsersError('Email address must be 254 characters or fewer.');
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $this->setUsersError('Enter a valid email address.');
                } elseif (
                    $password !== ''
                    && (
                        mb_strlen($password) > 128
                        || !preg_match('/[A-Z]/', $password)
                        || !preg_match('/[a-z]/', $password)
                        || !preg_match('/[0-9]/', $password)
                    )
                ) {
                    $this->setUsersError('A new password must be 128 characters or fewer and include uppercase, lowercase, and a number.');
                } elseif (!in_array($status, ['invited', 'active', 'suspended', 'disabled'], true)) {
                    $this->setUsersError('Choose a valid account status.');
                } elseif (($current['status'] ?? '') === 'invited' && $status === 'active') {
                    $this->setUsersError('Use the approval action to activate an invited account.');
                } elseif ($this->dashboardModel->emailExists($email, $id)) {
                    $this->setUsersError('Another account already uses this email.');
                } elseif (
                    ($current['status'] ?? '') === 'active'
                    && $status !== 'active'
                    && $this->isLastActivePrivilegedUser($id, (string) $current['status'], $status)
                ) {
                    $this->setUsersError('You cannot disable the last active administrator.');
                } else {
                    $this->dashboardModel->updateUser($id, $name, $email, $status, $password ?: null);
                    $this->audit->record((int) $user['id'], 'user.updated', 'user', (string) $id);
                }

                $this->redirect('/app/Controllers/DashboardController.php?view=users');
            }

            if ($action === 'approve-account') {
                $id = (int) ($_POST['user_id'] ?? 0);
                $pendingUser = $this->dashboardModel->findUser($id);
                if (!$pendingUser || ($pendingUser['status'] ?? '') !== 'invited') {
                    $this->setUsersError('This account is no longer waiting for approval.');
                } elseif (!$this->dashboardModel->canApproveAccount($user, $pendingUser)) {
                    $this->setUsersError('You are not authorized to approve this account type.');
                } elseif ($this->dashboardModel->approveAccount($id)) {
                    $this->audit->record(
                        (int) $user['id'],
                        'user.approved',
                        'user',
                        (string) $id,
                        ['status' => 'invited'],
                        ['status' => 'active']
                    );
                } else {
                    $this->setUsersError('This account could not be approved. Refresh and try again.');
                }

                $redirectView = ($_POST['view'] ?? '') === 'approvals' ? 'approvals' : 'users';
                $this->redirect('/app/Controllers/DashboardController.php?view=' . $redirectView);
            }

            if ($action === 'delete-user') {
                $id = (int) ($_POST['user_id'] ?? 0);
                $current = $this->dashboardModel->findUser($id);

                if (!$canManageUsers) {
                    $this->setUsersError('You are not allowed to manage users.');
                } elseif (!$current || $id === (int) $user['id']) {
                    $this->setUsersError('You cannot remove your own account.');
                } elseif (
                    ($current['status'] ?? '') === 'active'
                    && $this->isLastActivePrivilegedUser($id, (string) $current['status'], 'deleted')
                ) {
                    $this->setUsersError('You cannot remove the last active administrator.');
                } else {
                    $this->dashboardModel->deleteUser($id);
                    $this->audit->record((int) $user['id'], 'user.deleted', 'user', (string) $id, $current);
                }

                $this->redirect('/app/Controllers/DashboardController.php?view=users');
            }

            if ($action === 'status-toggle' && $canManageUsers) {
                $id = (int) ($_POST['user_id'] ?? 0);
                $current = $this->dashboardModel->findUser($id);
                if ($current && $id !== (int) $user['id']) {
                    if (($current['status'] ?? '') === 'invited') {
                        $this->setUsersError('Use the approval action to activate an invited account.');
                    } else {
                        $nextStatus = ($current['status'] ?? '') === 'active' ? 'disabled' : 'active';
                        if ($this->isLastActivePrivilegedUser($id, (string) $current['status'], $nextStatus)) {
                            $this->setUsersError('You cannot disable the last active administrator.');
                            $this->redirect('/app/Controllers/DashboardController.php?view=users');
                        }
                        $this->dashboardModel->updateStatus($id, $nextStatus);
                        $this->audit->record((int) $user['id'], 'user.status_changed', 'user', (string) $id, ['status' => $current['status']], ['status' => $nextStatus]);
                    }
                }
            }

            if ($action === 'reset-demo') {
                if ($this->dashboardModel->can($user, 'settings.manage', $config['roles'])) {
                    $this->dashboardModel->reset();
                    unset($_SESSION['user']);
                    $this->redirect('/login');
                }

                $this->setUsersError('You are not allowed to reset demo data.');
                $this->redirect('/app/Controllers/DashboardController.php?view=settings');
            }

            $this->redirect('/app/Controllers/DashboardController.php?view=' . urlencode((string) ($_POST['view'] ?? 'overview')));
        }

        $canReadRoles = $this->dashboardModel->can($user, 'roles.read', $config['roles']);
        $managedRoles = $canReadRoles ? $this->dashboardModel->allRoles() : [];
        foreach ($managedRoles as &$managedRole) {
            $managedRole['member_count'] = $this->dashboardModel->roleMemberCount((int) $managedRole['id']);
            $managedRole['permission_ids'] = $this->dashboardModel->rolePermissions((int) $managedRole['id']);
            $managedRole['members'] = $this->dashboardModel->roleUsers((int) $managedRole['id']);
        }
        unset($managedRole);
        $canManageIndividualPermissions = $this->dashboardModel->hasRole((int) $user['id'], 'admin')
            && $this->dashboardModel->can($user, 'users.manage', $config['roles']);
        $userPermissionCatalog = $canManageIndividualPermissions
            ? $this->dashboardModel->allPermissions()
            : [];
        $allUsers = $canReadUsers ? $this->dashboardModel->allUsers() : [];
        $overviewCounts = [
            'users_total' => count($allUsers),
            'users_active' => count(array_filter($allUsers, fn(array $listedUser): bool => ($listedUser['status'] ?? '') === 'active')),
            'users_pending' => count(array_filter($allUsers, fn(array $listedUser): bool => ($listedUser['status'] ?? '') === 'invited')),
            'users_blocked' => count(array_filter($allUsers, fn(array $listedUser): bool => in_array($listedUser['status'] ?? '', ['suspended', 'disabled'], true))),
            'admins' => count(array_filter($allUsers, fn(array $listedUser): bool => ($listedUser['role'] ?? '') === 'admin')),
        ];
        $userPage = $this->paginateRows(
            $allUsers,
            'users_page'
        );
        $users = $userPage['items'];
        foreach ($users as &$listedUser) {
            $listedUser['assigned_roles'] = $this->dashboardModel->rolesForUser((int) $listedUser['id']);
            if ($canManageIndividualPermissions) {
                $listedUser['effective_permissions'] = $this->dashboardModel->permissionsForUser((int) $listedUser['id']);
            }
            $listedUser['can_approve'] = ($listedUser['status'] ?? '') === 'invited'
                && $this->dashboardModel->canApproveAccount($user, $listedUser);
        }
        unset($listedUser);
        $canReadTeams = $this->dashboardModel->can($user, 'teams.read', $config['roles']);
        $teams = $canReadTeams ? $this->teams->allForUser(
            (int) $user['id'],
            $this->dashboardModel->hasRole((int) $user['id'], 'admin')
                && $this->dashboardModel->can($user, 'settings.manage', $config['roles'])
        ) : [];
        $overviewCounts['teams'] = count($teams);
        $teamPage = $this->paginateRows($teams, 'teams_page');
        $teams = $teamPage['items'];
        foreach ($teams as &$team) {
            $memberPage = $this->paginateRows(
                $this->teams->members((int) $team['id']),
                'team_' . (int) $team['id'] . '_members_page'
            );
            $team['members'] = $memberPage['items'];
            $team['members_pagination'] = $memberPage['pagination'];
            $team['roles'] = $this->teams->roles((int) $team['id']);
        }
        unset($team);

        $canReadAudit = $this->dashboardModel->can($user, 'audit_logs.read', $config['roles']);
        $canReadRequests = $this->dashboardModel->can($user, 'requests.read', $config['roles'])
            || $this->dashboardModel->can($user, 'requests.create', $config['roles']);
        $requestScope = $this->dashboardModel->hasRole((int) $user['id'], 'admin')
            ? 'all'
            : ($this->dashboardModel->hasRole((int) $user['id'], 'manager') && $canReviewRequests
                ? 'team'
                : 'own');
        $pendingApprovals = ($canApproveAccounts || $this->dashboardModel->can($user, 'users.manage', $config['roles']))
            ? $this->dashboardModel->pendingAccountsForApproval($user)
            : [];
        $overviewCounts['pending_approvals'] = count($pendingApprovals);
        $approvalPage = $this->paginateRows($pendingApprovals, 'approvals_page');
        $pendingApprovals = $approvalPage['items'];
        foreach ($pendingApprovals as &$pendingApproval) {
            $pendingApproval['can_approve'] = $this->dashboardModel->canApproveAccount($user, $pendingApproval);
        }
        unset($pendingApproval);
        $allPermissionCatalog = $this->dashboardModel->can($user, 'permissions.read', $config['roles'])
                ? $this->dashboardModel->allPermissions()
                : [];
        $overviewCounts['permissions'] = count($allPermissionCatalog);
        $permissionPage = $this->paginateRows($allPermissionCatalog, 'permissions_page');
        $allAccessRequests = $canReadRequests
                ? $this->accessRequests->allForUser((int) $user['id'], $requestScope)
                : [];
        $overviewCounts['pending_requests'] = count(array_filter(
            $allAccessRequests,
            fn(array $request): bool => ($request['status'] ?? '') === 'pending'
        ));
        $pendingAccessRequests = array_values(array_filter(
            $allAccessRequests,
            static fn(array $request): bool => ($request['status'] ?? '') === 'pending'
        ));
        $completedAccessRequests = array_values(array_filter(
            $allAccessRequests,
            static fn(array $request): bool => ($request['status'] ?? '') !== 'pending'
        ));
        $pendingAccessRequestPage = $this->paginateRows($pendingAccessRequests, 'pending_requests_page');
        $completedAccessRequestPage = $this->paginateRows($completedAccessRequests, 'completed_requests_page');
        $pendingRequestedPermissionIds = array_map(
            'intval',
            array_column(
                array_filter(
                    $allAccessRequests,
                    static fn(array $request): bool =>
                        ($request['request_type'] ?? '') === 'permission'
                        && ($request['status'] ?? '') === 'pending'
                ),
                'permission_id'
            )
        );
        $requestablePermissions = array_values(array_filter(
            $canCreateAccessRequest
                ? $this->dashboardModel->allPermissions()
                : [],
            static fn(array $permission): bool =>
                !in_array($permission['permission_key'], $user['effective_permissions'], true)
                && !in_array((int) $permission['id'], $pendingRequestedPermissionIds, true)
        ));
        $auditPage = $this->paginateRows(
            $canReadAudit ? $this->audit->recent() : [],
            'audit_page'
        );
        $this->render('DashboardView', [
            'user' => $user,
            'view' => $view,
            'permissions' => $config['permissions'],
            'roles' => $config['roles'],
            'users' => $users,
            'overviewCounts' => $overviewCounts,
            'reportSummary' => [
                'users_total' => $canReadUsers ? (int) $overviewCounts['users_total'] : null,
                'users_active' => $canReadUsers ? (int) $overviewCounts['users_active'] : null,
                'teams' => (int) ($overviewCounts['teams'] ?? 0),
                'pending_approvals' => (int) ($overviewCounts['pending_approvals'] ?? 0),
                'pending_requests' => (int) ($overviewCounts['pending_requests'] ?? 0),
            ],
            'usersPagination' => $userPage['pagination'],
            'canManageIndividualPermissions' => $canManageIndividualPermissions,
            'userPermissionCatalog' => $userPermissionCatalog,
            'managedRoles' => $managedRoles,
            'permissionCatalog' => $permissionPage['items'],
            'permissionsPagination' => $permissionPage['pagination'],
            'pendingAccessRequests' => $pendingAccessRequestPage['items'],
            'pendingRequestsPagination' => $pendingAccessRequestPage['pagination'],
            'completedAccessRequests' => $completedAccessRequestPage['items'],
            'completedRequestsPagination' => $completedAccessRequestPage['pagination'],
            'canCreateAccessRequest' => $canCreateAccessRequest,
            'requestablePermissions' => $requestablePermissions,
            'pendingApprovals' => $pendingApprovals,
            'approvalsPagination' => $approvalPage['pagination'],
            'auditLogs' => $auditPage['items'],
            'auditPagination' => $auditPage['pagination'],
            'usersError' => $usersError,
            'accountCreated' => $accountCreated,
            'availableRoles' => $this->dashboardModel->can($user, 'roles.assign', $config['roles']) ? $this->dashboardModel->allRoles() : [],
            'grantableRoles' => $this->dashboardModel->can($user, 'users.invite', $config['roles']) ? $this->dashboardModel->grantableRoles($user) : [],
            'teams' => $teams,
            'teamsPagination' => $teamPage['pagination'],
            'titles' => [
                'overview' => 'Overview',
                'reports' => $user['role'] === 'manager' ? 'Team Reports' : 'Reports',
                'team' => 'My Team',
                'users' => ($user['role'] ?? '') === 'manager'
                    ? 'Employee account creation'
                    : 'Users & roles',
                'roles' => 'Roles',
                'permissions' => 'Permissions',
                'requests' => 'Access requests',
                'approvals' => 'Approvals',
                'audit-logs' => 'Audit logs',
                'teams' => 'Teams',
                'settings' => 'Settings',
                'my-permissions' => 'My Permissions',
            ],
        ]);
    }

}
