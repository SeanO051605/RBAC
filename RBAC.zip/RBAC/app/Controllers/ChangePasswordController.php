<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\DashboardModel;
use App\Models\SecurityModel;

class ChangePasswordController
{
    private DashboardModel $dashboard;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->dashboard = new DashboardModel();
        $this->audit = new AuditLogModel();
    }

    private function redirect(string $path): void
    {
        $basePath = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        header('Location: ' . $basePath . $path);
        exit;
    }

    public function index(): void
    {
        $sessionUser = $_SESSION['user'] ?? null;
        if (!$sessionUser || !isset($sessionUser['id'])) {
            $this->redirect('/login');
        }

        $user = $this->dashboard->findUser((int) $sessionUser['id']);
        if (!$user || ($user['status'] ?? '') !== 'active') {
            unset($_SESSION['user']);
            $this->redirect('/login');
        }
        if (empty($user['must_change_password'])) {
            $this->redirect('/dashboard');
        }

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = $_POST['password'] ?? null;
            $confirmation = $_POST['password_confirmation'] ?? null;
            if (!SecurityModel::verifyCsrf($_POST['csrf_token'] ?? null)) {
                http_response_code(400);
                $error = 'Your form session expired. Reload the page and try again.';
            } elseif (!is_string($password) || !is_string($confirmation)) {
                $error = 'Enter and confirm your new password.';
            } elseif ($password !== $confirmation) {
                $error = 'The password confirmation does not match.';
            } elseif (
                $password === ''
                || mb_strlen($password) > 128
                || !preg_match('/[A-Z]/', $password)
                || !preg_match('/[a-z]/', $password)
                || !preg_match('/[0-9]/', $password)
            ) {
                $error = 'Password must be 128 characters or fewer and include uppercase, lowercase, and a number.';
            } else {
                try {
                    $this->dashboard->changePassword((int) $user['id'], $password);
                    $user = $this->dashboard->findUser((int) $user['id']);
                    if (!$user) {
                        throw new \RuntimeException('The account could not be loaded after the password change.');
                    }
                    session_regenerate_id(true);
                    $_SESSION['user'] = $user;
                    $this->audit->record(
                        (int) $user['id'],
                        'user.password_changed',
                        'user',
                        (string) $user['id']
                    );
                    $this->redirect('/dashboard');
                } catch (\InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            }
        }

        $basePath = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        $csrfToken = SecurityModel::csrfToken();
        require dirname(__DIR__) . '/Views/ChangePasswordView.php';
    }
}
