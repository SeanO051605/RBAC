<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\InvitationModel;
use App\Models\RegisterModel;
use App\Models\SecurityModel;

class RegisterController
{
    private InvitationModel $invitations;
    private RegisterModel $registrations;
    private AuditLogModel $audit;

    private function render(string $view, array $data = []): void
    {
        $data['basePath'] = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        extract($data, EXTR_SKIP);
        $file = dirname(__DIR__) . '/Views/' . basename($view) . '.php';

        if (!is_file($file)) {
            throw new \RuntimeException('View not found: ' . $view);
        }

        require $file;
    }

    private function redirect(string $path): void
    {
        $basePath = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        header('Location: ' . $basePath . $path);
        exit;
    }

    public function __construct()
    {
        $this->invitations = new InvitationModel();
        $this->registrations = new RegisterModel();
        $this->audit = new AuditLogModel();
    }

    public function index(): void
    {
        if (!empty($_SESSION['user'])) {
            $this->redirect('/app/Controllers/DashboardController.php');
        }

        $queryToken = $_GET['token'] ?? '';
        $token = is_string($queryToken) ? trim($queryToken) : '';
        $invitation = $token === '' ? null : $this->invitations->findValid($token);
        $error = '';
        $fields = [
            'name' => $invitation['name'] ?? '',
            'email' => $invitation['email'] ?? '',
        ];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $postedToken = $_POST['token'] ?? '';
            $token = is_string($postedToken) ? trim($postedToken) : '';
            $invitation = $token === '' ? null : $this->invitations->findValid($token);
            $password = $_POST['password'] ?? null;
            $confirm = $_POST['confirm'] ?? null;

            if (!SecurityModel::verifyCsrf($_POST['csrf_token'] ?? null)) {
                http_response_code(400);
                $error = 'Your form session expired. Reload the page and try again.';
            } elseif (!is_string($password) || !is_string($confirm)) {
                $error = 'Enter a valid password and confirmation.';
            } elseif (!$invitation) {
                http_response_code(400);
                $error = 'This invitation is invalid, expired, or already used.';
            } elseif ($password === '' || mb_strlen($password) > 128 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password)) {
                $error = 'Password must be 128 characters or fewer and include uppercase, lowercase, and a number.';
            } elseif ($password !== $confirm) {
                $error = 'Passwords do not match.';
            } else {
                try {
                    $user = $this->registrations->registerFromInvitation($token, $password);
                    $this->audit->record((int) $user['id'], 'account.pending_approval', 'user', (string) $user['id'], null, [
                        'email' => $user['email'],
                    ]);
                    $this->redirect('/app/Controllers/LoginController.php?pending_approval=1');
                } catch (\RuntimeException $exception) {
                    $error = $exception->getMessage();
                    $invitation = $this->invitations->findValid($token);
                }
            }
        }

        if ($invitation) {
            $fields = ['name' => $invitation['name'], 'email' => $invitation['email']];
        } elseif ($error === '') {
            $error = 'GateKeeper accounts are invitation-only. Ask an administrator to invite you.';
        }

        $this->render('RegisterView', [
            'error' => $error,
            'fields' => $fields,
            'invitation' => $invitation,
            'invitationToken' => $token,
            'csrfToken' => SecurityModel::csrfToken(),
        ]);
    }
}
