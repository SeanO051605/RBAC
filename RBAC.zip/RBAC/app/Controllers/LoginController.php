<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\LoginModel;
use App\Models\SecurityModel;

class LoginController
{
    private LoginModel $loginModel;
    private AuditLogModel $audit;

    private function render(string $view, array $data = []): void
    {
        $data['basePath'] = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        extract($data, EXTR_SKIP);
        $file = dirname(__DIR__) . '/Views/' . basename($view) . '.php';

        if (!is_file($file)) {
            throw new \RuntimeException('View not found: ' . $view);
        }

        require $file;
    }

    private function redirect(string $path): void
    {
        $basePath = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
        header('Location: ' . $basePath . $path);
        exit;
    }

    public function __construct()
    {
        $this->loginModel = new LoginModel();
        $this->audit = new AuditLogModel();
    }

    public function index(): void
    {
        $error = '';
        $email = '';
        $notice = isset($_GET['pending_approval'])
            ? 'Your invitation has been accepted. An Admin or Manager must approve your account, depending on its account type, before you can sign in.'
            : '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $emailValue = $_POST['email'] ?? null;
            $passwordValue = $_POST['password'] ?? null;

            if (!SecurityModel::verifyCsrf($_POST['csrf_token'] ?? null)) {
                http_response_code(400);
                $error = 'Your form session expired. Reload the page and try again.';
            } elseif (!is_string($emailValue) || !is_string($passwordValue)) {
                $error = 'Enter a valid email address and password.';
            } elseif (mb_strlen(trim($emailValue)) > 254) {
                $error = 'Enter a valid email address.';
            } elseif (!filter_var(trim($emailValue), FILTER_VALIDATE_EMAIL)) {
                $error = 'Enter a valid email address.';
            } elseif ($passwordValue === '') {
                $error = 'Password is required.';
            } else {
                $email = trim($emailValue);
                $password = $passwordValue;
                $user = $this->loginModel->authenticate($email, $password);
                if (!$user) {
                    $error = 'Invalid email or password.';
                    $this->audit->record(null, 'login.failed', 'user', null, null, ['email' => strtolower($email)], 'failure');
                } else {
                    session_regenerate_id(true);
                    $_SESSION['user'] = $user;
                    $this->audit->record((int) $user['id'], 'login.succeeded', 'user', (string) $user['id']);
                    if (!empty($user['must_change_password'])) {
                        $this->redirect('/change-password');
                    }
                    $this->redirect('/app/Controllers/DashboardController.php?tab_authenticated=1');
                }
            }
        }

        $this->render('LoginView', [
            'error' => $error,
            'email' => $email,
            'notice' => $notice,
            'csrfToken' => SecurityModel::csrfToken(),
        ]);
    }
}
