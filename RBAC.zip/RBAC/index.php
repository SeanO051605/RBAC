<?php

ini_set('session.use_strict_mode', '1');
session_set_cookie_params([
    'httponly' => true,
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');

define('APP_BASE_PATH', rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\'));

require __DIR__ . '/app/Models/Database.php';
require __DIR__ . '/app/Models/AuthorizationModel.php';
require __DIR__ . '/app/Models/AuditLogModel.php';
require __DIR__ . '/app/Models/SecurityModel.php';
require __DIR__ . '/app/Models/InvitationModel.php';
require __DIR__ . '/app/Models/RegisterModel.php';
require __DIR__ . '/app/Models/AccessRequestModel.php';
require __DIR__ . '/app/Models/TeamModel.php';
require __DIR__ . '/app/Models/UserModel.php';
require __DIR__ . '/app/Models/LoginModel.php';
require __DIR__ . '/app/Models/DashboardModel.php';
require __DIR__ . '/app/Controllers/LoginController.php';
require __DIR__ . '/app/Controllers/RegisterController.php';
require __DIR__ . '/app/Controllers/ChangePasswordController.php';
require __DIR__ . '/app/Controllers/LogoutController.php';
require __DIR__ . '/app/Controllers/DashboardController.php';

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$uri = $uri === '' ? '/' : rtrim($uri, '/');

if (APP_BASE_PATH !== '' && ($uri === APP_BASE_PATH || strpos($uri, APP_BASE_PATH . '/') === 0)) {
    $uri = substr($uri, strlen(APP_BASE_PATH));
}

$uri = $uri === '' ? '/' : $uri;

$routeMap = [
    '/' => ['LoginController', 'index'],
    '/login' => ['LoginController', 'index'],
    '/register' => ['RegisterController', 'index'],
    '/change-password' => ['ChangePasswordController', 'index'],
    '/dashboard' => ['DashboardController', 'index'],
    '/logout' => ['LogoutController', 'index'],
    '/app/Controllers/LoginController.php' => ['LoginController', 'index'],
    '/app/Controllers/RegisterController.php' => ['RegisterController', 'index'],
    '/app/Controllers/ChangePasswordController.php' => ['ChangePasswordController', 'index'],
    '/app/Controllers/DashboardController.php' => ['DashboardController', 'index'],
    '/app/Controllers/LogoutController.php' => ['LogoutController', 'index'],
];

if (!isset($routeMap[$uri])) {
    http_response_code(404);
    echo 'Page not found';
    exit;
}

[$controllerName, $method] = $routeMap[$uri];
$controllerClass = '\\App\\Controllers\\' . $controllerName;

try {
    $controller = new $controllerClass();
    $controller->$method();
} catch (\PDOException $error) {
    error_log('GateKeeper database error: ' . $error->getMessage());
    http_response_code(503);
    echo 'The GateKeeper database is unavailable or not initialized. Start MySQL, import database/schema.sql, and check the database environment settings.';
} catch (\Throwable $error) {
    error_log('GateKeeper application error: ' . $error);
    http_response_code(500);
    echo 'The request could not be completed. Please try again later.';
}
