CREATE DATABASE IF NOT EXISTS rbac_portal
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE rbac_portal;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(254) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(80) NOT NULL DEFAULT 'employee',
    status ENUM('active', 'invited', 'suspended', 'disabled') NOT NULL DEFAULT 'invited',
    avatar VARCHAR(500) NULL,
    last_login_at DATETIME NULL,
    mfa_enabled TINYINT(1) NOT NULL DEFAULT 0,
    email_verified_at DATETIME NULL,
    must_change_password TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY users_email_unique (email),
    KEY users_role_index (role),
    KEY users_status_index (status)
) ENGINE=InnoDB;

ALTER TABLE users
    MODIFY role VARCHAR(80) NOT NULL DEFAULT 'employee',
    MODIFY status ENUM('pending', 'active', 'invited', 'suspended', 'disabled') NOT NULL DEFAULT 'invited',
    ADD COLUMN IF NOT EXISTS avatar VARCHAR(500) NULL,
    ADD COLUMN IF NOT EXISTS last_login_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS mfa_enabled TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS email_verified_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS must_change_password TINYINT(1) NOT NULL DEFAULT 0;

UPDATE users SET status = 'invited' WHERE status = 'pending';

ALTER TABLE users
    MODIFY status ENUM('active', 'invited', 'suspended', 'disabled') NOT NULL DEFAULT 'invited';

CREATE TABLE IF NOT EXISTS roles (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    slug VARCHAR(80) NOT NULL,
    description VARCHAR(500) NOT NULL DEFAULT '',
    type ENUM('system', 'custom') NOT NULL DEFAULT 'custom',
    status ENUM('active', 'archived') NOT NULL DEFAULT 'active',
    is_protected TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY roles_slug_unique (slug),
    KEY roles_status_index (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permissions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    permission_key VARCHAR(120) NOT NULL,
    category VARCHAR(80) NOT NULL,
    description VARCHAR(255) NOT NULL DEFAULT '',
    PRIMARY KEY (id),
    UNIQUE KEY permissions_key_unique (permission_key),
    KEY permissions_category_index (category)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INT UNSIGNED NOT NULL,
    permission_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    CONSTRAINT role_permissions_role_fk FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
    CONSTRAINT role_permissions_permission_fk FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_roles (
    user_id INT UNSIGNED NOT NULL,
    role_id INT UNSIGNED NOT NULL,
    assigned_by INT UNSIGNED NULL,
    expires_at DATETIME NULL,
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, role_id),
    CONSTRAINT user_roles_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT user_roles_role_fk FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT user_roles_assigner_fk FOREIGN KEY (assigned_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE user_roles
    ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL;

CREATE TABLE IF NOT EXISTS user_permission_overrides (
    user_id INT UNSIGNED NOT NULL,
    permission_id INT UNSIGNED NOT NULL,
    is_granted TINYINT(1) NOT NULL,
    assigned_by INT UNSIGNED NULL,
    expires_at DATETIME NULL,
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, permission_id),
    CONSTRAINT user_permission_overrides_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT user_permission_overrides_permission_fk FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE,
    CONSTRAINT user_permission_overrides_assigner_fk FOREIGN KEY (assigned_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE user_permission_overrides
    ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL;

CREATE TABLE IF NOT EXISTS teams (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(120) NOT NULL,
    description VARCHAR(500) NOT NULL DEFAULT '',
    status ENUM('active', 'archived') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY teams_status_index (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS team_members (
    team_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    added_by INT UNSIGNED NULL,
    added_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (team_id, user_id),
    CONSTRAINT team_members_team_fk FOREIGN KEY (team_id) REFERENCES teams (id) ON DELETE CASCADE,
    CONSTRAINT team_members_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT team_members_adder_fk FOREIGN KEY (added_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS team_roles (
    team_id INT UNSIGNED NOT NULL,
    role_id INT UNSIGNED NOT NULL,
    assigned_by INT UNSIGNED NULL,
    expires_at DATETIME NULL,
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (team_id, role_id),
    CONSTRAINT team_roles_team_fk FOREIGN KEY (team_id) REFERENCES teams (id) ON DELETE CASCADE,
    CONSTRAINT team_roles_role_fk FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT team_roles_assigner_fk FOREIGN KEY (assigned_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE team_roles
    ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL;

CREATE TABLE IF NOT EXISTS invitations (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(254) NOT NULL,
    name VARCHAR(120) NOT NULL,
    token_hash CHAR(64) NOT NULL,
    role_id INT UNSIGNED NOT NULL,
    invited_by INT UNSIGNED NULL,
    status ENUM('pending', 'accepted', 'cancelled', 'expired') NOT NULL DEFAULT 'pending',
    expires_at DATETIME NOT NULL,
    accepted_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY invitations_token_hash_unique (token_hash),
    KEY invitations_email_status_index (email, status),
    CONSTRAINT invitations_role_fk FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT invitations_inviter_fk FOREIGN KEY (invited_by) REFERENCES users (id) ON DELETE RESTRICT
) ENGINE=InnoDB;

ALTER TABLE invitations
    MODIFY invited_by INT UNSIGNED NULL;

CREATE TABLE IF NOT EXISTS access_requests (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    requester_id INT UNSIGNED NOT NULL,
    request_type ENUM('role', 'permission', 'resource') NOT NULL,
    role_id INT UNSIGNED NULL,
    permission_id INT UNSIGNED NULL,
    resource_type VARCHAR(80) NULL,
    resource_id VARCHAR(120) NULL,
    justification TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'expired', 'cancelled') NOT NULL DEFAULT 'pending',
    approver_id INT UNSIGNED NULL,
    decision_note TEXT NULL,
    decided_at DATETIME NULL,
    expires_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY access_requests_status_index (status),
    KEY access_requests_requester_index (requester_id),
    CONSTRAINT access_requests_requester_fk FOREIGN KEY (requester_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT access_requests_role_fk FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE SET NULL,
    CONSTRAINT access_requests_permission_fk FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE SET NULL,
    CONSTRAINT access_requests_approver_fk FOREIGN KEY (approver_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    actor_id INT UNSIGNED NULL,
    action VARCHAR(120) NOT NULL,
    target_type VARCHAR(80) NOT NULL,
    target_id VARCHAR(120) NULL,
    before_data JSON NULL,
    after_data JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    result ENUM('success', 'failure') NOT NULL DEFAULT 'success',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY audit_actor_created_index (actor_id, created_at),
    KEY audit_action_created_index (action, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS login_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(254) NOT NULL,
    ip_address VARCHAR(45) NULL,
    succeeded TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY login_attempts_email_time_index (email, attempted_at),
    KEY login_attempts_ip_time_index (ip_address, attempted_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    type VARCHAR(80) NOT NULL,
    message VARCHAR(500) NOT NULL,
    read_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY notifications_user_created_index (user_id, created_at),
    CONSTRAINT notifications_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO roles (name, slug, description, type, status, is_protected) VALUES
('Admin', 'admin', 'Organization-wide user, role, team, request, audit, and settings management.', 'system', 'active', 1),
('Manager', 'manager', 'Team-level supervision, approvals, and reports.', 'system', 'active', 1),
('Employee', 'employee', 'Standard employee account.', 'system', 'active', 1);

UPDATE roles SET
    name = CASE slug
        WHEN 'admin' THEN 'Admin'
        WHEN 'manager' THEN 'Manager'
        WHEN 'employee' THEN 'Employee'
    END,
    type = 'system',
    status = 'active',
    is_protected = 1
WHERE slug IN ('admin', 'manager', 'employee');

UPDATE users
SET role = CASE
    WHEN role = 'admin' THEN 'admin'
    WHEN role = 'manager' THEN 'manager'
    ELSE 'employee'
END;

UPDATE roles SET status = 'archived'
WHERE slug NOT IN ('admin', 'manager', 'employee');

UPDATE invitations i
JOIN roles r ON r.id = i.role_id
SET i.status = 'cancelled'
WHERE i.status = 'pending'
  AND r.slug NOT IN ('admin', 'manager', 'employee');

UPDATE access_requests ar
JOIN roles r ON r.id = ar.role_id
SET ar.status = 'cancelled'
WHERE ar.status = 'pending'
  AND r.slug NOT IN ('admin', 'manager', 'employee');

DELETE tr
FROM team_roles tr
JOIN roles r ON r.id = tr.role_id
WHERE r.slug NOT IN ('admin', 'manager', 'employee');

DELETE ur
FROM user_roles ur
JOIN roles r ON r.id = ur.role_id
JOIN users u ON u.id = ur.user_id
WHERE r.slug NOT IN ('admin', 'manager', 'employee')
   OR r.slug <> u.role;

INSERT IGNORE INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u
JOIN roles r ON r.slug = u.role AND r.status = 'active';

INSERT IGNORE INTO permissions (permission_key, category, description) VALUES
('dashboard:read', 'dashboard', 'View dashboards'),
('users:read', 'users', 'View user directory'),
('users:invite', 'users', 'Invite users'),
('users:approve', 'users', 'Approve employee accounts'),
('users:create', 'users', 'Create users'),
('users:update', 'users', 'Update users'),
('users:delete', 'users', 'Delete users'),
('roles:read', 'roles', 'View roles'),
('roles:create', 'roles', 'Create roles'),
('roles:update', 'roles', 'Update roles and permissions'),
('roles:delete', 'roles', 'Delete roles'),
('roles:assign', 'roles', 'Assign or revoke roles'),
('teams:read', 'teams', 'View teams'),
('teams:create', 'teams', 'Create teams'),
('teams:update', 'teams', 'Manage team membership'),
('teams:delete', 'teams', 'Delete teams'),
('requests:read', 'requests', 'View access requests'),
('requests:create', 'requests', 'Submit access requests'),
('requests:approve', 'requests', 'Approve access requests'),
('requests:reject', 'requests', 'Reject access requests'),
('reports:view', 'reports', 'View reports'),
('reports:export', 'reports', 'Export reports'),
('audit_logs:read', 'audit_logs', 'View audit logs'),
('audit_logs:export', 'audit_logs', 'Export audit logs'),
('settings:read', 'settings', 'View system settings'),
('settings:update', 'settings', 'Update system settings'),
('permissions:read', 'permissions', 'View the permission catalog and matrix'),
('profile:read', 'profile', 'View own profile'),
('profile:update', 'profile', 'Update own profile'),
('tasks:read', 'tasks', 'View assigned tasks'),
('tasks:update', 'tasks', 'Update assigned tasks'),
('notifications:read', 'notifications', 'View own notifications');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r CROSS JOIN permissions p
WHERE r.slug = 'admin'
  AND p.permission_key NOT IN (
      'profile:read', 'profile:update', 'tasks:read', 'tasks:update',
      'notifications:read', 'requests:create'
  );

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r JOIN permissions p ON p.permission_key IN (
    'dashboard:read', 'teams:read', 'teams:update', 'users:read', 'users:invite', 'users:approve', 'requests:read', 'requests:approve',
    'requests:reject', 'reports:view', 'profile:read', 'profile:update', 'tasks:read',
    'tasks:update', 'notifications:read'
)
WHERE r.slug = 'manager';

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r JOIN permissions p ON p.permission_key IN (
    'dashboard:read', 'requests:create', 'profile:read', 'profile:update',
    'tasks:read', 'tasks:update', 'notifications:read'
)
WHERE r.slug = 'employee';

DELETE rp
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
JOIN permissions p ON p.id = rp.permission_id
WHERE r.slug = 'manager' AND p.permission_key = 'users:read';

DELETE rp
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
JOIN permissions p ON p.id = rp.permission_id
WHERE r.slug = 'admin' AND p.permission_key = 'requests:create';
